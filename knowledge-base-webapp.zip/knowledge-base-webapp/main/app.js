var app = angular.module("KnowledgeBase", [
  "ui.router",
  "restangular",
  "ngCookies",
  "ngMaterial",
  "ngAria",
  "ngAnimate",
  "rzSlider",
]);
