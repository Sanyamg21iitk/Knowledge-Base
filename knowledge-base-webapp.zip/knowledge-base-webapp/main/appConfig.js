"use strict";

(function () {
  angular
    .module("KnowledgeBase")
    .config(function ($stateProvider, $urlRouterProvider) {
      $stateProvider
        .state({
          name: "dashboard",
          url: "/user/dashboard?search&page&score_min&score_max&ordering",
          templateUrl: "../modules/account/dashboard/dashboard.html",
          controller: "dashboardController",
          params: {
            search: {
              dynamic: true,
            },
            score_min: {
              dynamic: true,
            },
            score_max: {
              dynamic: true,
            },
            page: {
              dynamic: true,
            },
            ordering: {
              dynamic: true,
            },
          },
        })
        .state({
          name: "profile",
          url: "/user/profile?id&tag",
          templateUrl: "../modules/account/profile/profile.html",
          controller: "profileController",
          params: {
            tag: {
              dynamic: true,
            },
          },
        })
        .state({
          name: "home",
          url: "/",
          templateUrl: "../modules/account/home/home.html",
        })
        .state({
          name: "email_verification",
          url: "/email",
          templateUrl:
            "../modules/account/emailVerification/emailVerification.html",
          controller: "emailController",
        })
        .state({
          name: "signup",
          url: "/register/:activation_key",
          templateUrl: "../modules/account/signup/signup.html",
          controller: "signupController",
        })
        .state({
          name: "login",
          url: "/login",
          templateUrl: "../modules/account/login/login.html",
          controller: "loginController",
        })
        .state({
          name: "bookmark",
          url: "/user/bookmarks?search&page",
          templateUrl: "../modules/account/bookmark/bookmark.html",
          controller: "bookmarkController",
          params: {
            search: {
              dynamic: true,
            },
            page: {
              dynamic: true,
            },
          },
        })
        .state({
          name: "editUser",
          url: "/user/edit",
          templateUrl: "../modules/account/editUser/editUser.html",
          controller: "editUserController",
        })
        .state({
          name: "changePassword",
          url: "/user/changepassword",
          templateUrl: "../modules/account/changePassword/changePassword.html",
          controller: "changePasswordController",
        })
        .state({
          name: "http500",
          url: "/error/http500",
          templateUrl: "../modules/error/http500.html",
        })
        .state({
          name: "createGroup",
          url: "/user/groups/create",
          templateUrl: "../modules/group/createGroup/createGroup.html",
          controller: "createGroupController",
        })
        .state({
          name: "groupDetail",
          url: "/user/groups/:id?tag&search&page",
          templateUrl: "../modules/group/groupDetail/groupDetail.html",
          controller: "groupDetailController",
          params: {
            tag: {
              dynamic: true,
            },
            search: {
              dynamic: true,
            },
            page: {
              dynamic: true,
            },
          },
        })
        .state({
          name: "groupList",
          url: "/user/groups?search&page",
          templateUrl: "../modules/group/groupList/groupList.html",
          controller: "groupListController",
          params: {
            search: {
              dynamic: true,
            },
            page: {
              dynamic: true,
            },
          },
        })
        .state({
          name: "groupEdit",
          url: "/user/groups/:id/edit?search&page",
          templateUrl: "../modules/group/editGroup/groupEdit.html",
          controller: "groupEditController",
          params: {
            search: {
              dynamic: true,
            },
            page: {
              dynamic: true,
            },
          },
        })
        .state({
          name: "createPost",
          url: "/user/posts/create",
          templateUrl: "../modules/post/createPost/createPost.html",
          controller: "createPostController",
        })
        .state({
          name: "postDetail",
          url: "/user/posts/:id",
          templateUrl: "../modules/post/postDetail/postDetail.html",
          controller: "postDetailController",
        })
        .state({
          name: "postList",
          url: "/user/posts?search&page&tag&tagSearch",
          templateUrl: "../modules/post/postList/postList.html",
          controller: "postListController",
          params: {
            search: {
              dynamic: true,
            },
            page: {
              dynamic: true,
            },
            tagSearch: {
              dynamic: true,
            },
            tag: {
              dynamic: true,
            },
          },
        })
        .state({
          name: "editPost",
          url: "/user/post/:id/edit",
          templateUrl: "../modules/post/editPost/editPost.html",
          controller: "editPostController",
        })
        .state({
          name: "sharePost",
          url: "/user/post/:id/share",
          templateUrl: "../modules/post/sharePost/sharePost.html",
          controller: "sharePostController",
        });

      $urlRouterProvider.otherwise("/");
    });

  angular
    .module("KnowledgeBase")
    .run(async function (
      $rootScope,
      $transitions,
      $cookies,
      Restangular,
      $state,
      APP_CONSTANTS
    ) {
      Restangular.setBaseUrl(APP_CONSTANTS.BASE_URL);
      Restangular.setRequestSuffix("/");
      Restangular.addFullRequestInterceptor(function (
        element,
        operation,
        what,
        url,
        headers,
        params
      ) {
        if ($cookies.get("token") && $cookies.get("token") != "") {
          Restangular.setDefaultHeaders({
            Authorization: `Token ${$cookies.get("token")}`,
          });
        }

        return {
          element: element,
          params: params,
          headers: headers,
        };
      });

      Restangular.setErrorInterceptor(function (
        response,
        deferred,
        responseHandler
      ) {
        switch (response.status) {
          case 401:
            $cookies.remove("userId");
            $cookies.remove("token");
            $state.go("login", {});
            return false;
          case 500:
            $state.go("http500");
            return false; //error Handled
        }
        return true; // error not handled
      });

      if ($cookies.get("userId") && $cookies.get("userId") != "") {
        $rootScope.userId = JSON.parse($cookies.get("userId"));
      }

      //acess only when user is not Authenticated
      const loginRoutes = ["login", "signup", "email_verification"];

      //access when authenticated and not Authenticated
      const publicRoutes = ["home"];

      $transitions.onBefore({ to: "*" }, function (transition) {
        $rootScope.state = transition.to().name;
        if (!publicRoutes.find((route) => route === transition.to().name)) {
          if ($cookies.get("token") && $cookies.get("token") != "") {
            if (loginRoutes.find((route) => route === transition.to().name))
              return transition.router.stateService.target("dashboard");
          } else {
            if (!loginRoutes.find((route) => route === transition.to().name))
              return transition.router.stateService.target("login");
          }
        }
      });
    });
})();
