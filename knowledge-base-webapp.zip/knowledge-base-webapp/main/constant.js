"use strict";
(function () {
  angular.module("KnowledgeBase").constant("APP_CONSTANTS", {
    BASE_URL: "http://127.0.0.1:8000",
    BASE_USER_ROUTE: "/account/user/",
    USER_BOOKMARKS_ROUTE: "/account/user/bookmarks",
    LOGIN_ROUTE: "/account/signin/",
    LOGOUT_ROUTE: "/account/signout/",
    EMAIL_ROUTE: "/account/email/",
    USER_REPORT_ROUTE: "/account/report/",
    GROUP_REPORT_ROUTE: "/group/report/",
    GROUP_BASE_ROUTE: "/group/",
    POST_BASE_ROUTE: "/post/",
    TAG_ROUTE: "/post/tags/",
    PASSWORD_EXPRESSION: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*#?&]{8,}$/,

    ROLES: [
      { id: 0, role: "owner" },
      { id: 1, role: "Admin" },
      { id: 2, role: "Member" },
    ],
    ROLE_TYPES: {
      OWNER: 0,
      ADMIN: 1,
      MEMBER: 2,
    },
    POST_TYPE: [
      { id: 1, type: "Private" },
      { id: 2, type: "Public" },
    ],
    POSTS: {
      PRIVATE: 0,
      PUBLIC: 1,
    },
    REACTION_TYPE: {
      UPVOTE: 1,
      DOWNVOTE: 2,
    },
    CHAR_FIELD_NAME: 255,
    CHAR_FIELD_ADDRESS: 255,
    CHAR_FIELD_TAG: 25,
    CHAR_FIELD_SHORT_DESCRIPTION: 500,
    TEXT_FIELD_DESCRIPTION: 1000,
    TEXT_AREA_DESCRIPTION_ROWS: 10,
    TEXT_AREA_COMMENT_ROWS: 5,
    ACTIVE_USER_OPTIONS: {
      ACTIVE_USER_BY_POST_CREATION: 1,
      ACTIVE_USERS_BY_COMMENT_POSTING: 2,
      ACTIVE_USERS_BY_REACTION: 3,
    },
    ORDER_BY_OPTIONS: {
      CREATED_AT: 1,
      SCORE: 2,
    },
    SORT_BY_OPTIONS: {
      MAX_AT_TOP: 1,
      MIN_AT_TOP: 2,
    },
  });
})();
