"use strict";
(function () {
  angular.module("KnowledgeBase").service("bookmarkApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.fetchBookmarkList = function (search, page) {
        return Restangular.one(APP_CONSTANTS.USER_BOOKMARKS_ROUTE).get({
          search,
          page,
        });
      };
      this.updateBookmark = function (postId, bookmarkId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .one("bookmark", bookmarkId)
          .patch(data);
      };
    },
  ]);
})();
