"use strict";
(function () {
  angular.module("KnowledgeBase").controller("bookmarkController", [
    "$scope",
    "bookmarkApiService",
    "$state",
    "$stateParams",
    "$mdDialog",
    "$controller",
    function (
      $scope,
      bookmarkApiService,
      $state,
      $stateParams,
      $mdDialog,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      //set params
      $scope.data = {};
      $scope.data.pageNumber = parseInt($stateParams.page) || 1;
      $scope.query = $stateParams.search || "";

      $scope.data.urlRefresh = function () {
        $state.go(
          "bookmark",
          {
            search: $scope.query,
            page: $scope.data.pageNumber,
          },
          {
            // prevent the events onStart and onSuccess from firing
            notify: false,
          }
        );
      };
      $scope.data.urlRefresh();

     
      $scope.data.getBookmarkList = function () {
        $scope.showPageLoader = true;
        bookmarkApiService
          .fetchBookmarkList($scope.query, $scope.data.pageNumber)
          .then(function (response) {
            $scope.showPageLoader = false;
            $scope.bookmarks = response.results;
            $scope.data.count = response.count;
            $scope.data.urlRefresh();
          })
          .catch(function (error) {
            $scope.showPageLoader = false;
            $scope.data.pageNumber = 1;
            $scope.data.getBookmarkList();
            $scope.setError(error);
          });
      };
      $scope.data.getBookmarkList();

      $scope.updateBookmark = function (note, postId, bookmarkId) {
        var confirm = $mdDialog
          .prompt()
          .title("Update note")
          .textContent("You can check it in your bookmarks tab")
          .placeholder("note")
          .initialValue(note)
          .required(true)
          .ok("Update")
          .cancel("Cancel");

        $mdDialog.show(confirm).then(
          function (result) {
            bookmarkApiService
              .updateBookmark(postId, bookmarkId, { note: result })
              .then(function (response) {
                $scope.data.getBookmarkList();
                $mdDialog.show(
                  $mdDialog
                    .alert()
                    .clickOutsideToClose(true)
                    .title("Success")
                    .textContent("Bookmark updated successfully")
                    .ok("OK")
                    .openFrom({
                      top: -50,
                      width: 30,
                      height: 80,
                    })
                    .closeTo({ left: 1500 })
                );
              })
              .catch(function (error) {
                $scope.setError(error);
              });
          },
          function () {}
        );
      };
    },
  ]);
})();
