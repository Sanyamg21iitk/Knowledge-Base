"use strict";
(function () {
  angular.module("KnowledgeBase").controller("changePasswordController", [
    "$scope",
    "editUserApiService",
    "$rootScope",
    "$state",
    function ($scope, editUserApiService, $rootScope, $state) {
      $scope.re = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
      $scope.compare = function () {
        $scope.isconfirm = $scope.password == $scope.repass ? true : false;
      };
      $scope.changePassword = function (update) {
        if ($scope.isconfirm && $scope.password) {
          editUserApiService
            .updateUser(update, $rootScope.user.id)
            .then((res) => {
              $state.go("profile", {})
            })
            .catch((e) => {
              switch (error.status) {
                case 400:
                  $scope.error = "Values incorrect!";
                  break;
                case 500:
                  $scope.error = "Server error try again!";
              }
            });
        } else {
          $scope.error = "Kindly Fill the Form First!";
        }
      };
    },
  ]);
})();
