"use strict";
(function () {
  angular.module("KnowledgeBase").service("dashboardApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.fetchUserList = function (
        search,
        page,
        ordering,
        score_min,
        score_max
      ) {
        return Restangular.one(APP_CONSTANTS.BASE_USER_ROUTE).get({
          search,
          page,
          ordering,
          score_min,
          score_max,
        });
      };
      this.fetchGroupUserSuggestions = function (search, group) {
        return Restangular.one(APP_CONSTANTS.BASE_USER_ROUTE).get({
          search,
          group,
        });
      };
    },
  ]);
})();
