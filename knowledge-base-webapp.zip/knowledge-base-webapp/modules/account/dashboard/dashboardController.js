"use strict";

(function () {
  angular.module("KnowledgeBase").controller("dashboardController", [
    "$scope",
    "dashboardApiService",
    "$stateParams",
    "$state",
    "$controller",
    "APP_CONSTANTS",
    function (
      $scope,
      dashboardApiService,
      $stateParams,
      $state,
      $controller,
      APP_CONSTANTS
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;

      $scope.reset = function () {
        $scope.pageNumber = 1;
        $scope.query = "";
        $scope.ordering = "-created_at";
        $scope.score_min = undefined;
        $scope.score_max = undefined;
        $scope.slider.minValue = 0;
        $scope.slider.maxValue = 0;
        $scope.order_by_option = APP_CONSTANTS.ORDER_BY_OPTIONS.CREATED_AT;
        $scope.sort_by_option = APP_CONSTANTS.SORT_BY_OPTIONS.MAX_AT_TOP;
        $scope.data.urlRefresh();
        $scope.data.getUserList();
      };

      $scope.sortByChanged = function () {
        $scope.ordering =
          $scope.order_by_option == APP_CONSTANTS.ORDER_BY_OPTIONS.CREATED_AT
            ? "created_at"
            : "score";
        $scope.ordering =
          $scope.sort_by_option == APP_CONSTANTS.SORT_BY_OPTIONS.MAX_AT_TOP
            ? "-" + $scope.ordering
            : $scope.ordering;
        $scope.data.getUserList();
      };

      $scope.data = {};
      //set params
      $scope.data.pageNumber = parseInt($stateParams.page) || 1;
      $scope.query = $stateParams.search || "";
      $scope.ordering = $stateParams.ordering || "-created_at";
      $scope.score_min = parseInt($stateParams.score_min) || undefined;
      $scope.score_max = parseInt($stateParams.score_max) || undefined;

      $scope.findInRangeClicked =
        $scope.score_min || $scope.score_max ? true : false;

      $scope.order_by_option =
        $scope.ordering === "created_at" || $scope.ordering === "-created_at"
          ? APP_CONSTANTS.ORDER_BY_OPTIONS.CREATED_AT
          : APP_CONSTANTS.ORDER_BY_OPTIONS.SCORE;

      $scope.order_by_created_at = APP_CONSTANTS.ORDER_BY_OPTIONS.CREATED_AT;
      $scope.order_by_score = APP_CONSTANTS.ORDER_BY_OPTIONS.SCORE;

      $scope.sort_by_option = $scope.ordering
        ? $scope.ordering[0] == "-"
          ? APP_CONSTANTS.SORT_BY_OPTIONS.MAX_AT_TOP
          : APP_CONSTANTS.SORT_BY_OPTIONS.MIN_AT_TOP
        : APP_CONSTANTS.SORT_BY_OPTIONS.MAX_AT_TOP;
      $scope.sort_by_max_at_top = APP_CONSTANTS.SORT_BY_OPTIONS.MAX_AT_TOP;
      $scope.sort_by_min_at_top = APP_CONSTANTS.SORT_BY_OPTIONS.MIN_AT_TOP;

      $scope.slider = {
        minValue: $scope.score_min || 0,
        maxValue: $scope.score_max || 0,
        options: {
          floor: 0,
          ceil: 100,
          step: 1,
          noSwitching: true,
        },
      };

      $scope.getUserInRange = function () {
        $scope.findInRangeClicked = true;
        $scope.score_min = $scope.slider.minValue;
        $scope.score_max = $scope.slider.maxValue;

        $scope.data.getUserList();
      };

      $scope.data.urlRefresh = function () {
        $state.go(
          "dashboard",
          {
            score_min: $scope.score_min,
            score_max: $scope.score_max,
            search: $scope.query,
            page: $scope.data.pageNumber,
            ordering: $scope.ordering,
          },
          {
            // prevent the events onStart and onSuccess from firing
            notify: false,
          }
        );
      };
      $scope.data.urlRefresh();

      $scope.data.getUserList = function () {
        $scope.showPageLoader = true;
        dashboardApiService
          .fetchUserList(
            $scope.query,
            $scope.data.pageNumber,
            $scope.ordering,
            $scope.order_by_option == 2 ? $scope.score_min : undefined,
            $scope.order_by_option == 2 ? $scope.score_max : undefined
          )
          .then(function (response) {
            $scope.showPageLoader = false;
            $scope.users = response.results;
            $scope.data.count = response.count;
            $scope.data.urlRefresh();
          })
          .catch(function (error) {
            $scope.showPageLoader = false;
            $scope.setError(error);
            $scope.pageNumber = 1;
            $scope.data.getUserList();
          });
      };
      $scope.data.getUserList();
    },
  ]);
})();
