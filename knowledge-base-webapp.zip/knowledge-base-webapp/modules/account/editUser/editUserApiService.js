"use strict";
(function () {
  angular.module("KnowledgeBase").service("editUserApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.updateUser = function (update, pk) {
        return Restangular.one(APP_CONSTANTS.BASE_USER_ROUTE, pk).customPATCH(
          update
        );
      };
    },
  ]);
})();
