"use strict";

(function () {
  angular.module("KnowledgeBase").controller("editUserController", [
    "$scope",
    "editUserApiService",
    "profileApiService",
    "$rootScope",
    "$state",
    "APP_CONSTANTS",
    "$controller",
    function (
      $scope,
      editUserApiService,
      profileApiService,
      $rootScope,
      $state,
      APP_CONSTANTS,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });

      $scope.addAddress = false;
      $scope.constants = APP_CONSTANTS;
      $scope.showPageLoader = true;
      $scope.re = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;

      $scope.isAddressChanged = function () {
        return !_.isEqual($scope.address, $scope.addressFetched);
      };

      profileApiService
        .fetchUserProfile($rootScope.userId)
        .then(function (response) {
          $scope.showPageLoader = false;
          $scope.user = response;
          $scope.firstNameFetched = $scope.user.first_name;
          $scope.lastNameFetched = $scope.user.last_name;
          $scope.address = response.address;
          if (!$scope.address) {
            $scope.address = {};
            $scope.address.adressline_1 = "";
            $scope.address.adressline_2 = "";
            $scope.address.city = "";
            $scope.address.state = "";
            $scope.address.zipcode = "";
          }

          $scope.addressFetched = Object.assign({}, $scope.address, {});
        })
        .catch(function (error) {
          $scope.showPageLoader = false;
          $scope.setError(error);
        });
      $scope.edit = function () {
        $scope.showLoader = true;
        var details = {
          first_name: $scope.user.first_name,
          last_name: $scope.user.last_name,
        };
        if ($scope.addAddress) {
          details.address = $scope.address;
        }

        editUserApiService
          .updateUser(details, $scope.user.id)
          .then(function (response) {
            $scope.showLoader = false;
            $state.go("profile", {});
          })
          .catch(function (error) {
            $scope.showLoader = false;
            $scope.setError(error);
          });
      };
    },
  ]);
})();
