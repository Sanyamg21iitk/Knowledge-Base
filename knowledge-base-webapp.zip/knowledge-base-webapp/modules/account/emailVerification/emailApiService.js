"use strict";
(function () {
  angular.module("KnowledgeBase").service("emailApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.verify = function (email) {
        return Restangular.all(APP_CONSTANTS.EMAIL_ROUTE).post(email);
      };
    },
  ]);
})();
