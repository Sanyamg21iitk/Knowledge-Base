"use strict";

(function () {
  angular.module("KnowledgeBase").controller("emailController", [
    "$scope",
    "emailApiService",
    "$controller",
    function ($scope, emailApiService, $controller) {
      $controller("commonUtilsController", { $scope: $scope });

      $scope.verify = function () {
        $scope.showLoader = true;
        emailApiService
          .verify($scope.user)
          .then(function (response) {
            $scope.showLoader = false;
            $scope.user = {};
            $scope.verificationForm.$setUntouched();
            $scope.message = "Check Your email!!!";
          })
          .catch(function (error) {
            $scope.showLoader = false;
            $scope.setError(error);
            $scope.user = {};
            $scope.verificationForm.$setUntouched();
          });
      };
    },
  ]);
})();
