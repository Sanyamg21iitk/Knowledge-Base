"use strict";
(function () {
  angular.module("KnowledgeBase").service("loginApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.login = function (credentials) {
        return Restangular.all(APP_CONSTANTS.LOGIN_ROUTE).post(credentials);
      };
    },
  ]);
})();
