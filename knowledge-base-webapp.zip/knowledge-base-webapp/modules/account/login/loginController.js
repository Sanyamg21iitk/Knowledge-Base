"use strict";

(function () {
  angular.module("KnowledgeBase").controller("loginController", [
    "$scope",
    "loginApiService",
    "$rootScope",
    "$cookies",
    "$state",
    "$controller",
    "APP_CONSTANTS",
    function (
      $scope,
      loginApiService,
      $rootScope,
      $cookies,
      $state,
      $controller,
      APP_CONSTANTS
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.re = APP_CONSTANTS.PASSWORD_EXPRESSION;

      $scope.login = function () {
        $scope.showLoader = true;
        loginApiService
          .login($scope.user)
          .then(function (response) {
            $scope.showLoader = false;
            $cookies.put("token", response.token);
            $cookies.put("userId", JSON.stringify(response.id));
            $rootScope.userId = response.id;
            $state.go("postList");
          })
          .catch(function (error) {
            $scope.showLoader = false;
            $scope.setError(error);
            $scope.user = {};
            $scope.Loginform.$setUntouched();
          });
      };
    },
  ]);
})();
