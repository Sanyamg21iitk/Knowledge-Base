"use strict";
(function () {
  angular.module("KnowledgeBase").service("profileApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.fetchUserReport = function (userId, params) {
        return Restangular.one(APP_CONSTANTS.USER_REPORT_ROUTE, userId).get(
          params
        );
      };
      this.fetchUserProfile = function (userId) {
        return Restangular.one(APP_CONSTANTS.BASE_USER_ROUTE, userId).get();
      };
    },
  ]);
})();
