"use strict";

(function () {
  angular.module("KnowledgeBase").controller("profileController", [
    "$scope",
    "profileApiService",
    "$rootScope",
    "$stateParams",
    "$state",
    "APP_CONSTANTS",
    "$controller",
    function (
      $scope,
      profileApiService,
      $rootScope,
      $stateParams,
      $state,
      APP_CONSTANTS,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;
      $scope.showPageLoader = true;

      $scope.urlRefresh = function (tag) {
        $state.go(
          "profile",
          {
            tag: tag.tag,
          },
          {
            // prevent the events onStart and onSuccess from firing
            notify: false,
          }
        );
      };

      $scope.loadProfile = function (tag) {
        profileApiService
          .fetchUserReport($stateParams.id || $rootScope.userId, {
            tag: tag ? tag.tag : $stateParams.tag,
          })
          .then(function (response) {
            $scope.user = response;
            if (response.address) {
              $scope.address = response.address;
              $scope.isAddressPresent = true;
            }
            $scope.showEdit = $scope.user.id == $rootScope.userId;
            $scope.showPageLoader = false;
          })
          .catch(function (error) {
            $scope.showPageLoader = false;
            $scope.setError(error);
          });
      };
      $scope.loadProfile();
    },
  ]);
})();
