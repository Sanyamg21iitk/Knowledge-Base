"use strict";
(function () {
  angular.module("KnowledgeBase").service("signupApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.postData = function (data) {
        return Restangular.all(APP_CONSTANTS.BASE_USER_ROUTE).post(data);
      };
      this.fetchEmail = function (activation_key) {
        return Restangular.one(APP_CONSTANTS.EMAIL_ROUTE, activation_key).get();
      };
    },
  ]);
})();
