"use strict";

(function () {
  angular.module("KnowledgeBase").controller("signupController", [
    "$scope",
    "signupApiService",
    "$stateParams",
    "$cookies",
    "$rootScope",
    "$state",
    "APP_CONSTANTS",
    "$controller",
    function (
      $scope,
      signupApiService,
      $stateParams,
      $cookies,
      $rootScope,
      $state,
      APP_CONSTANTS,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });

      $scope.re = APP_CONSTANTS.PASSWORD_EXPRESSION;
      $scope.user = {};

      $scope.compare = function (repass) {
        $scope.isconfirm = $scope.user.password == repass ? true : false;
      };

      signupApiService
        .fetchEmail($stateParams.activation_key)
        .then(function (response) {
          $scope.user.email = response.email;
        })
        .catch(function (error) {
          $scope.setError(error);
        });

      $scope.postdata = function () {
        $scope.showLoader = true;
        $scope.user.activation_key = $stateParams.activation_key;
        delete $scope.user.email;
        signupApiService
          .postData($scope.user)
          .then(function (response) {
            $scope.showLoader = false;
            $cookies.put("token", response.token);
            $cookies.put("userId", JSON.stringify(response.id));
            $rootScope.userId = response.id;
            $state.go("postList");
          })
          .catch(function (error) {
            $scope.setError(error);
            $scope.showLoader = false;
          });
      };
    },
  ]);
})();
