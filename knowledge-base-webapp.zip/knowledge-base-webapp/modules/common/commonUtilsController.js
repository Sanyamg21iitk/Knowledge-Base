"use strict";

(function () {
  angular.module("KnowledgeBase").controller("commonUtilsController", [
    "$scope",
    "$timeout",
    function ($scope, $timeout) {
      $scope.setError = function (error) {
        $scope.error =
          error.data[Object.keys(error.data)[0]] instanceof Array
            ? error.data[Object.keys(error.data)[0]][0]
            : error.data[Object.keys(error.data)[0]];
        $timeout(() => {
          $scope.error = "";
        }, 3000);
      };

      $scope.formTouched = function () {
        $scope.error = null;
      };
    },
  ]);
})();
