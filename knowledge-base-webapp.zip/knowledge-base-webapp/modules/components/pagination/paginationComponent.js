"use strict";

(function () {
  angular.module("KnowledgeBase").component("pagination", {
    bindings: {
      pageNumber: "=",
      count: "=",
      refreshPage: "&",
      urlRefresh: "&",
    },
    controller: "paginationController",
    templateUrl: "modules/components/pagination/pagination.html",
  });
})();
