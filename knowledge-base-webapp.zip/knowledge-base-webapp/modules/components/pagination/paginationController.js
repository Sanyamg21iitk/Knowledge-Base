"use strict";

(function () {
  angular.module("KnowledgeBase").controller("paginationController", [
    "$scope",
    function ($scope) {
      $scope.goNext = function () {
        $scope.$ctrl.pageNumber += 1;
        setTimeout(function () {
          $scope.$ctrl.refreshPage();
          $scope.$ctrl.urlRefresh();
        }, 0);
      };
      $scope.goPrevious = function () {
        $scope.$ctrl.pageNumber -= 1;
        setTimeout(function () {
          $scope.$ctrl.refreshPage();
          $scope.$ctrl.urlRefresh();
        }, 0);
      };
    },
  ]);
})();
