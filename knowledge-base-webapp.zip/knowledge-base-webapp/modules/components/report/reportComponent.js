"use strict";
(function () {
  angular.module("KnowledgeBase").component("reportComponent", {
    controller: "reportController",
    bindings: {
      user: "=",
      group: "=",
      urlRefresh: "&",
      getReportCard: "&",
    },
    templateUrl: "modules/components/report/reportTemplate.html",
  });
})();
