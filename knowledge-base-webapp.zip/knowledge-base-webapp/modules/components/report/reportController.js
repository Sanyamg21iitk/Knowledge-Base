"use strict";

(function () {
  angular.module("KnowledgeBase").controller("reportController", [
    "$scope",
    "profileApiService",
    "$rootScope",
    "$stateParams",
    "$state",
    "postListApiService",
    "APP_CONSTANTS",
    "createPostApiService",
    "$controller",

    function (
      $scope,
      profileApiService,
      $rootScope,
      $stateParams,
      $state,
      postListApiService,
      APP_CONSTANTS,
      createPostApiService,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;
      $scope.pageNumber = parseInt($stateParams.page) || 1;
      $scope.query = $stateParams.search || "";
      $scope.tagPageNumber = 1;
      $scope.showPageLoader = true;
      $scope.tags = [];
      $scope.tagList = [];
      $scope.tag = "";

      $scope.state = $state.current.name;

      $scope.transformChip = function (chip) {
        return chip.name;
      };

      if ($stateParams.tag) {
        $scope.tag = $stateParams.tag;
        $scope.tags = $stateParams.tag.split(",");
      }

      $scope.tagsChanged = function () {
        $scope.tag = "";
        $scope.tags.forEach((tag) => ($scope.tag += tag + ","));
        $scope.tag = $scope.tag.substr(0, $scope.tag.length - 1);
        $scope.$ctrl.getReportCard({ tag: $scope.tag });
        $scope.$ctrl.urlRefresh({ tag: $scope.tag });
      };

      $scope.querySearch = function (tagSearchQuery) {
        createPostApiService
          .loadTagSuggestions(tagSearchQuery)
          .then((res) => {
            $scope.tagList = res.results;
            $scope.tagList = $scope.tagList.filter((tag) => {
              return !$scope.tags.find((selectedTag) => {
                return selectedTag == tag.name;
              });
            });
          })
          .catch((error) => {
            $scope.setError(error);
          });
      };
    },
  ]);
})();
