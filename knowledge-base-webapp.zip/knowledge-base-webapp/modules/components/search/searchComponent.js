"use strict";

(function () {
  angular.module("KnowledgeBase").component("search", {
    bindings: {
      query: "=",
      refreshPage: "&",
      urlRefresh: "&",
      pageNumber: "&",
    },
    controller: "searchController",
    templateUrl: "modules/components/search/search.html",
  });
})();
