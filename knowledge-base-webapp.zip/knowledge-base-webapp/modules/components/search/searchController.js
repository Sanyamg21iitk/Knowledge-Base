"use strict";

(function () {
  angular.module("KnowledgeBase").controller("searchController", [
    "$scope",
    "APP_CONSTANTS",
    function ($scope, APP_CONSTANTS) {
      $scope.constants = APP_CONSTANTS;

      $scope.search = function () {
        if ($scope.$ctrl.query) {
          $scope.$ctrl.pageNumber = 1;
          setTimeout(function () {
            $scope.$ctrl.refreshPage();
            $scope.$ctrl.urlRefresh();
          }, 0);
        }

        $scope.resetSearch = function () {
          if ($scope.$ctrl.query) {
            $scope.$ctrl.pageNumber = 1;
            $scope.$ctrl.query = "";
            setTimeout(function () {
              $scope.$ctrl.refreshPage();
              $scope.$ctrl.urlRefresh();
            }, 0);
          }
        };
      };
    },
  ]);
})();
