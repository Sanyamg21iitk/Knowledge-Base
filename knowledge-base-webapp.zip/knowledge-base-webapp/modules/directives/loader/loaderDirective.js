"use strict";

(function () {
  angular.module("KnowledgeBase").directive("loader", function () {
    return {
      templateUrl: "modules/directives/loader/loader.html",
    };
  });
})();
