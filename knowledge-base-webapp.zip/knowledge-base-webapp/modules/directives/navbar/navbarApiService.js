"use strict";
(function () {
  angular.module("KnowledgeBase").service("navbarApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.logout = function () {
        return Restangular.one(APP_CONSTANTS.LOGOUT_ROUTE).post();
      };
    },
  ]);
})();
