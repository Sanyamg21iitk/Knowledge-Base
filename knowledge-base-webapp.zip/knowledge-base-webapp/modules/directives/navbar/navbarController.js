"use strict";

(function () {
  angular.module("KnowledgeBase").controller("navbarController", [
    "$scope",
    "$cookies",
    "$state",
    "navbarApiService",
    "$rootScope",
    function ($scope, $cookies, $state, navbarApiService, $rootScope) {
      $rootScope.$watch("state", function (newVal, oldVal) {
        $scope.isAuthenticated =
          $cookies.get("token") && $cookies.get("token") != "";
      });

      $scope.logout = function () {
        navbarApiService
          .logout()
          .then(function (response) {
            $cookies.remove("token");
            $cookies.remove("userId");
            $scope.isAuthenticated = false;
            $state.go("login", {});
          })
          .catch(function (error) {});
      };
    },
  ]);
})();
