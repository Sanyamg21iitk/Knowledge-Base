"use strict";

(function () {
  angular.module("KnowledgeBase").directive("navbar", function () {
    return {
      templateUrl: "modules/directives/navbar/navbar.html",
      controller: "navbarController",
    };
  });
})();
