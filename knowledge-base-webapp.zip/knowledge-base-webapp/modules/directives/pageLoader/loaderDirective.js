"use strict";

(function () {
  angular.module("KnowledgeBase").directive("pageLoader", function () {
    return {
      templateUrl: "modules/directives/pageLoader/loader.html",
    };
  });
})();
