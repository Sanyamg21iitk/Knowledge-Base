"use strict";
(function () {
  angular.module("KnowledgeBase").service("createGroupApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.createGroup = function (group) {
        return Restangular.all(APP_CONSTANTS.GROUP_BASE_ROUTE).post(group);
      };
    },
  ]);
})();
