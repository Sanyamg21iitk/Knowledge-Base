"use strict";

(function () {
  angular.module("KnowledgeBase").controller("createGroupController", [
    "$scope",
    "createGroupApiService",
    "dashboardApiService",
    "$rootScope",
    "$state",
    "$mdDialog",
    "APP_CONSTANTS",
    "$controller",
    function (
      $scope,
      createGroupApiService,
      dashboardApiService,
      $rootScope,
      $state,
      $mdDialog,
      APP_CONSTANTS,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;
      $scope.group = {
        name: "",
        short_description: "",
        users: [],
      };
      $scope.suggestions = [];
      $scope.selectedItem = null;
      $scope.transformChip = function (chip) {
        return chip.name;
      };

      $scope.searchSuggestions = function (search) {
        dashboardApiService
          .fetchUserList(search)
          .then(function (response) {
            $scope.error = "";
            $scope.suggestions = response.results.filter((user) => {
              return (
                !$scope.group.users.find((newuser) => {
                  return newuser.id == user.id;
                }) && user.id != $rootScope.userId
              );
            });
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };

      $scope.createGroup = function () {
        const group = {
          name: $scope.group.name,
          short_description: $scope.group.short_description || "",
          users: [],
        };
        $scope.group.users.forEach((user) => group.users.push(user.id));
        $scope.showLoader = true;
        createGroupApiService
          .createGroup(group)
          .then((group) => {
            $scope.error = "";
            $scope.showLoader = false;
            $mdDialog
              .show(
                $mdDialog
                  .alert()
                  .textContent("Group Created Successfully!!!")
                  .ok("OK")
                  .openFrom({
                    top: -50,
                    width: 30,
                    height: 80,
                  })
                  .closeTo({ left: 1500 })
              )
              .finally(function () {
                $state.go("groupDetail", { id: group.id });
              });
          })
          .catch((error) => {
            $scope.showLoader = false;
            $scope.setError(error);
          });
      };
    },
  ]);
})();
