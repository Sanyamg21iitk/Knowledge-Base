"use strict";
(function () {
  angular.module("KnowledgeBase").service("groupEditApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.editGroup = function (update, pk) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE, pk).customPATCH(
          update
        );
      };

      this.changeRole = function (role, pk, user) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE, pk)
          .one("members", user)
          .customPATCH(role);
      };

      this.addNewUsers = function (users, pk) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE, pk)
          .all("members")
          .post(users);
      };

      this.removeUser = function (pk, user) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE, pk)
          .one("members", user)
          .remove();
      };

      this.fetchGroupUserSuggestions = function (search, group) {
        return Restangular.one(APP_CONSTANTS.BASE_USER_ROUTE).get({
          search,
          group,
        });
      };
    },
  ]);
})();
