"use strict";

(function () {
  angular.module("KnowledgeBase").controller("groupEditController", [
    "$scope",
    "groupEditApiService",
    "$rootScope",
    "$stateParams",
    "$state",
    "APP_CONSTANTS",
    "groupBaseApiService",
    "$controller",
    function (
      $scope,
      groupEditApiService,
      $rootScope,
      $stateParams,
      $state,
      APP_CONSTANTS,
      groupBaseApiService,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      if (!$stateParams.id) {
        return $state.go("groupList");
      }
      $scope.data = {};
      $scope.constants = APP_CONSTANTS;
      $scope.getGroupDetails = function () {
        groupBaseApiService
          .fetchGroupDetails($stateParams.id)
          .then(function (response) {
            $scope.error = "";
            if (response.role == APP_CONSTANTS.ROLE_TYPES.MEMBER) {
              $state.go("groupList");
            }
            $scope.group = response;
            $scope.canChangeRole =
              response.role == APP_CONSTANTS.ROLE_TYPES.OWNER;
            $scope.isAdminOrOwner =
              $scope.canChangeRole ||
              response.role == APP_CONSTANTS.ROLE_TYPES.ADMIN;
            $scope.data.getGroupUserList();
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };

      $scope.canRemove = function (user) {
        if ($scope.isAdminOrOwner) {
          switch (user.role.id) {
            case APP_CONSTANTS.ROLE_TYPES.OWNER:
              return $scope.canChangeRole && user.user.id != $rootScope.userId;
            default:
              return $scope.isAdminOrOwner && user.user.id != $rootScope.userId;
          }
        }
        return false;
      };

      $scope.data.urlRefresh = function () {
        $state.go(
          "groupEdit",
          {
            page: $scope.data.pageNumber,
            search: $scope.query,
          },
          {
            // prevent the events onStart and onSuccess from firing
            notify: false,
            // prevent reload of the current state
          }
        );
      };

      $scope.editGroup = function () {
        $scope.showSaveLoader = true;
        const group = {
          name: $scope.group.name,
          short_description: $scope.group.short_description,
        };
        groupEditApiService
          .editGroup(group, $stateParams.id)
          .then((response) => {
            $scope.showSaveLoader = false;
          })
          .catch((error) => {
            $scope.showSaveLoader = false;
            $scope.setError(error);
          });
      };

      $scope.addNewUsers = function () {
        $scope.showAddUserLoader = true;
        const users = [];
        $scope.newUsers.forEach((user) => {
          users.push({
            user_id: user.id,
            role: APP_CONSTANTS.ROLE_TYPES.MEMBER,
          });
        });
        groupEditApiService
          .addNewUsers(users, $scope.group.id)
          .then((response) => {
            $scope.showAddUserLoader = false;
            $scope.newUsers = [];
            $scope.data.getGroupUserList();
          })
          .catch((error) => {
            $scope.showAddUserLoader = false;
            $scope.setError(error);
          });
      };
      $scope.getRole = function (roleId) {
        return APP_CONSTANTS.ROLES.find((role) => role.id == roleId);
      };
      $scope.getRoles = function () {
        return APP_CONSTANTS.ROLES;
      };

      //Suggestions start
      $scope.newUsers = [];
      $scope.suggestions = [];
      $scope.selectedItem = null;
      $scope.transformChip = function (chip) {
        return chip.name;
      };
      $scope.searchSuggestions = function (searchQuery) {
        groupEditApiService
          .fetchGroupUserSuggestions(searchQuery, $scope.group.id)
          .then(function (response) {
            $scope.suggestions = response.results.filter((user) => {
              return (
                user.id != $rootScope.userId &&
                !$scope.newUsers.find((newuser) => newuser.id == user.id)
              );
            });
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };
      //suggestions end

      $scope.changeRole = function (user, role) {
        groupEditApiService
          .changeRole({ role }, $scope.group.id, user)
          .then((response) => {
            $scope.error = "";
            if (response.user.id == $rootScope.userId) {
              if (response.role == APP_CONSTANTS.ROLE_TYPES.MEMBER)
                return $state.go("groupList");
              if (response.role == APP_CONSTANTS.ROLE_TYPES.ADMIN)
                $scope.data.getGroupUserList();
              $scope.canChangeRole = false;
            }
          })
          .catch((error) => {
            $scope.data.getGroupUserList();
            $scope.setError(error);
          });
      };

      //set params
      $scope.data.pageNumber = parseInt($stateParams.page) || 1;
      $scope.query = $stateParams.search || "";

      $scope.data.getGroupUserList = function () {
        $scope.showPageLoader = true;
        groupBaseApiService
          .fetchGroupUserList(
            $stateParams.id,
            $scope.data.pageNumber,
            $scope.query
          )
          .then(function (response) {
            $scope.showPageLoader = false;
            $scope.users = response.results;
            $scope.users.forEach((user) => {
              user.role = $scope.getRole(user.role);
            });
            $scope.data.count = response.count;
            $scope.data.urlRefresh();
          })
          .catch(function (error) {
            $scope.showPageLoader = false;
            $scope.data.pageNumber = 1;
            $scope.data.urlRefresh();
            $scope.setError(error);
          });
      };
      $scope.getGroupDetails();
      $scope.postLeave = function () {
        $scope.data.getGroupUserList();
      };
      $controller("groupBaseController", { $scope: $scope });
    },
  ]);
})();
