"use strict";
(function () {
  angular.module("KnowledgeBase").service("groupBaseApiService", [
    "Restangular",
    "APP_CONSTANTS",
    "$rootScope",
    function (Restangular, APP_CONSTANTS, $rootScope) {
      this.fetchGroupReport = function (pk, params) {
        return Restangular.one(APP_CONSTANTS.GROUP_REPORT_ROUTE, pk).get(
          params
        );
      };

      this.fetchGroupDetails = function (pk) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE, pk).get();
      };

      this.unsubscribe = function (data) {
        return Restangular.one(
          APP_CONSTANTS.BASE_USER_ROUTE,
          $rootScope.userId
        ).patch(data);
      };

      this.fetchGroupUserList = function (pk, page, search) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE, pk)
          .one("members")
          .get({
            page,
            search,
          });
      };

      this.removeUser = function (pk, user) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE, pk)
          .one("members", user)
          .remove();
      };
    },
  ]);
})();
