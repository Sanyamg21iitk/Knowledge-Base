"use strict";

(function () {
  angular.module("KnowledgeBase").controller("groupBaseController", [
    "$scope",
    "groupBaseApiService",
    "$rootScope",
    "$state",
    "$mdDialog",
    "$controller",
    function (
      $scope,
      groupBaseApiService,
      $rootScope,
      $state,
      $mdDialog,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.showConfirm = function (user) {
        var confirm = $mdDialog
          .confirm()
          .title("Confirm ?")
          .ok("Yes")
          .cancel("No");
        $mdDialog.show(confirm).then(
          function () {
            $scope.leave(user);
          },
          function () {}
        );
      };


      $scope.leave = function (user) {
        $scope.showLeaveLoader = true;
        groupBaseApiService
          .removeUser($scope.group.id, user)
          .then((response) => {
            //  go to group list
            $scope.error = "";
            $scope.showLeaveLoader = false;
            $scope.postLeave();
          })
          .catch((error) => {
            $scope.showLeaveLoader = false;
            $scope.setError(error);
          });
      };
    },
  ]);
})();
