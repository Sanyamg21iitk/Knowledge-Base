"use strict";

(function () {
  angular.module("KnowledgeBase").controller("groupDetailController", [
    "$scope",
    "groupBaseApiService",
    "$rootScope",
    "$stateParams",
    "$state",
    "APP_CONSTANTS",
    "$controller",
    "$mdDialog",
    "createPostApiService",
    function (
      $scope,
      groupBaseApiService,
      $rootScope,
      $stateParams,
      $state,
      APP_CONSTANTS,
      $controller,
      $mdDialog,
      createPostApiService
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;
      $scope.tagPageNumber = 1;
      $scope.tagList = [];
      $scope.tags = [];
      $scope.data = {};
      $scope.active_users_option =
        APP_CONSTANTS.ACTIVE_USER_OPTIONS.ACTIVE_USER_BY_POST_CREATION;

      $scope.active_users_by_post_creation =
        APP_CONSTANTS.ACTIVE_USER_OPTIONS.ACTIVE_USER_BY_POST_CREATION;

      $scope.active_users_by_comment_posting =
        APP_CONSTANTS.ACTIVE_USER_OPTIONS.ACTIVE_USERS_BY_COMMENT_POSTING;

      $scope.active_users_by_reaction =
        APP_CONSTANTS.ACTIVE_USER_OPTIONS.ACTIVE_USERS_BY_REACTION;

      $scope.unsubscribe = function () {
        groupBaseApiService
          .unsubscribe({ toggle_unsubscribe_group_id: $stateParams.id })
          .then(function (response) {
            $scope.group.is_subscribed = !$scope.group.is_subscribed;
            $mdDialog.show(
              $mdDialog
                .alert()
                .clickOutsideToClose(true)
                .textContent(
                  "Group" +
                    ($scope.group.is_subscribed
                      ? " Subscribed "
                      : " Unsubscribed ") +
                    "Successfully!!!"
                )
                .ok("OK")
                .openFrom({
                  top: -50,
                  width: 30,
                  height: 80,
                })
                .closeTo({ left: 1500 })
            );
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };

      if (!$stateParams.id) {
        return $state.go("groupList");
      }

      if ($stateParams.tag) {
        $scope.tag = $stateParams.tag;
        $scope.tags = $stateParams.tag.split(",");
      }

      $scope.fetchGroupReport = function (tag) {
        groupBaseApiService
          .fetchGroupReport($stateParams.id, {
            tag: tag ? tag.tag : $stateParams.tag,
          })
          .then(function (response) {
            $scope.group = response;
            $scope.roleType = response.role;
            $scope.canEdit = response.role != APP_CONSTANTS.ROLE_TYPES.MEMBER;
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };
      $scope.fetchGroupReport();

      $scope.urlRefresh = function (tag) {
        $state.go(
          "groupDetail",
          {
            tag: tag.tag,
            page: $scope.data.pageNumber,
            search: $scope.query,
          },
          {
            // prevent the events onStart and onSuccess from firing
            notify: false,
            // prevent reload of the current state
          }
        );
      };

      $scope.goNext = function () {
        $scope.pageNumber += 1;
        $scope.getGroupUserList();
      };
      $scope.goPrevious = function () {
        $scope.pageNumber -= 1;
        $scope.getGroupUserList();
      };

      $scope.getRole = function (roleId) {
        return APP_CONSTANTS.ROLES.find((role) => role.id == roleId).role;
      };

      //set params
      $scope.data.pageNumber = parseInt($stateParams.page) || 1;
      $scope.query = $stateParams.search || "";

      
      $scope.data.getGroupUserList = function () {
        groupBaseApiService
          .fetchGroupUserList(
            $stateParams.id,
            $scope.data.pageNumber,
            $scope.query
          )
          .then(function (response) {
            $scope.users = response.results;
            $scope.data.count = response.count;
          })
          .catch(function (error) {
            $scope.data.pageNumber = 1;
            $scope.setError(error);
            $scope.data.urlRefresh();
          });
      };
      $scope.userId = $rootScope.userId;
      $scope.data.getGroupUserList();
      $scope.postLeave = function () {
        $state.go("groupList");
      };
      $controller("groupBaseController", { $scope: $scope });
    },
  ]);
})();
