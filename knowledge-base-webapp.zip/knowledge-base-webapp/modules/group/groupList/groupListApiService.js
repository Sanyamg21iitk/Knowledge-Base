"use strict";
(function () {
  angular.module("KnowledgeBase").service("groupListApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.fetchGroupList = function (page, search) {
        return Restangular.one(APP_CONSTANTS.GROUP_BASE_ROUTE).get({
          page,
          search,
        });
      };
    },
  ]);
})();
