"use strict";

(function () {
  angular.module("KnowledgeBase").controller("groupListController", [
    "$scope",
    "groupListApiService",
    "$stateParams",
    "APP_CONSTANTS",
    "$controller",
    "$state",
    function (
      $scope,
      groupListApiService,
      $stateParams,
      APP_CONSTANTS,
      $controller,
      $state
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;
      $scope.data = {};

      //set params
      $scope.data.pageNumber = parseInt($stateParams.page) || 1;
      $scope.searchQuery = {
        query: $stateParams.search || "",
      };

      $scope.data.urlRefresh = function () {
        $state.go(
          "groupList",
          {
            search: $scope.searchQuery.query,
            page: $scope.data.pageNumber,
          },
          {
            // prevent the events onStart and onSuccess from firing
            notify: false,
          }
        );
      };
      $scope.data.urlRefresh();

      $scope.data.getGroupList = function () {
        $scope.showPageLoader = true;
        groupListApiService
          .fetchGroupList($scope.data.pageNumber, $scope.searchQuery.query)
          .then(function (response) {
            $scope.showPageLoader = false;
            $scope.groups = response.results;
            $scope.data.count = response.count;
            $scope.data.urlRefresh();
          })
          .catch(function (error) {
            $scope.showPageLoader = false;
            $scope.setError(error);
            $scope.data.pageNumber = 1;
            $scope.data.getGroupList();
          });
      };
      $scope.data.getGroupList();
    },
  ]);
})();
