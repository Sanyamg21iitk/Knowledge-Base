"use strict";
(function () {
  angular.module("KnowledgeBase").service("createPostApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.createPost = function (post) {
        return Restangular.all(APP_CONSTANTS.POST_BASE_ROUTE).post(post);
      };

      this.loadTagSuggestions = function (search) {
        return Restangular.one(APP_CONSTANTS.TAG_ROUTE).get({
          search,
        });
      };
    },
  ]);
})();
