"use strict";

(function () {
  angular.module("KnowledgeBase").controller("createPostController", [
    "$scope",
    "createPostApiService",
    "groupListApiService",
    "$state",
    "$mdDialog",
    "APP_CONSTANTS",
    "$controller",
    function (
      $scope,
      createPostApiService,
      groupListApiService,
      $state,
      $mdDialog,
      APP_CONSTANTS,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;
      $scope.tagList = [];

      $scope.querySearch = function (tagSearchQuery) {
        createPostApiService
          .loadTagSuggestions(tagSearchQuery)
          .then((res) => {
            $scope.tagList = res.results;
          })
          .catch((error) => {
            $scope.setError(error);
          });
      };

      $scope.selectedItem = null;
      $scope.tags = [];
      $scope.transformChip = function (chip) {
        return chip.name;
      };

      $scope.init = function () {
        $scope.post = {
          post_type: $scope.postType[APP_CONSTANTS.POSTS.PUBLIC],
          tags: [],
        };
      };

      $scope.postType = APP_CONSTANTS.POST_TYPE;
      $scope.init();
      $scope.changeType = function () {
        $scope.showGroup = true;
        if (
          $scope.post.post_type.id ==
          APP_CONSTANTS.POST_TYPE[APP_CONSTANTS.POSTS.PUBLIC].id
        ) {
          $scope.post.group = null;
          $scope.showGroup = false;
        }
      };

      $scope.validate = function () {
        if (
          $scope.post.post_type.id ==
            APP_CONSTANTS.POST_TYPE[APP_CONSTANTS.POSTS.PRIVATE].id &&
          $scope.post.group == null
        ) {
          return false;
        }
        return true;
      };

      $scope.searchGroups = function () {
        groupListApiService
          .fetchGroupList(1, $scope.groupName)
          .then(function (response) {
            $scope.suggestions = response.results;
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };

      $scope.create = function () {
        var data = {
          title: $scope.post.title,
          description: $scope.post.description,
          tags: $scope.post.tags.map((tag) => {
            return { name: tag };
          }),
          post_type: $scope.post.post_type.id,
        };
        if ($scope.post.group) {
          data.group_id = $scope.post.group.id;
        }
        delete $scope.post.group;
        $scope.showLoader = true;

        createPostApiService
          .createPost(data)
          .then(function (response) {
            $scope.showLoader = false;
            $mdDialog
              .show(
                $mdDialog
                  .alert()
                  .clickOutsideToClose(true)
                  .textContent("Post Created Successfully!!!")
                  .ok("OK")
                  .openFrom({
                    top: -50,
                    width: 30,
                    height: 80,
                  })
                  .closeTo({ left: 1500 })
              )
              .finally(function () {
                $state.go("postDetail", { id: response.id });
              });
          })
          .catch(function (error) {
            $scope.showLoader = false;
            $scope.setError(error);
            $scope.init();
          });
      };
    },
  ]);
})();
