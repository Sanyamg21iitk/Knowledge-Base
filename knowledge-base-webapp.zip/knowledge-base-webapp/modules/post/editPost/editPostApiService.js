"use strict";
(function () {
  angular.module("KnowledgeBase").service("editPostApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.fetchPostDetails = function (pk) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, pk).get();
      };

      this.updatePost = function (postId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId).patch(
          data
        );
      };

      this.loadTagSuggestions = function (search) {
        return Restangular.one(APP_CONSTANTS.TAG_ROUTE).get({
          search,
        });
      };
    },
  ]);
})();
