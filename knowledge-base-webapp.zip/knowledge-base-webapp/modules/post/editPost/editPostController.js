"use strict";

(function () {
  angular.module("KnowledgeBase").controller("editPostController", [
    "$scope",
    "editPostApiService",
    "$state",
    "$stateParams",
    "$mdDialog",
    "APP_CONSTANTS",
    "$controller",
    function (
      $scope,
      editPostApiService,
      $state,
      $stateParams,
      $mdDialog,
      APP_CONSTANTS,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.post = {
        title: "",
        description: "",
        tags: [],
      };
      $scope.constants = APP_CONSTANTS;
      $scope.tagList = [];

      $scope.querySearch = function (tagSearch) {
        editPostApiService
          .loadTagSuggestions(tagSearch)
          .then((res) => {
            $scope.tagList = res.results;
          })
          .catch((error) => {
            $scope.setError(error);
          });
      };

      $scope.selectedItem = null;
      $scope.tags = [];
      $scope.transformChip = function (chip) {
        return chip.name;
      };

      $scope.isSomethingChanged = function () {
        if (
          $scope.post.title != $scope.titleFetched ||
          $scope.post.description != $scope.descriptionFetched ||
          !_.isEqual($scope.tagsFetched, $scope.post.tags)
        ) {
          return true;
        }
        return false;
      };

      $scope.fetchPostDetails = function () {
        editPostApiService
          .fetchPostDetails($stateParams.id)
          .then(function (response) {
            $scope.post.title = response.title;
            $scope.titleFetched = response.title;
            let tags = [];
            if (response.tag)
              response.tag.forEach((tag) => tags.push(tag.name));
            $scope.post.tags = tags;
            $scope.tagsFetched = [].concat(tags);
            $scope.post.description = response.description;
            $scope.descriptionFetched = response.description;
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };
      $scope.fetchPostDetails();

      $scope.update = function () {
        var data = {
          title: $scope.post.title,
          description: $scope.post.description,
          tags: $scope.post.tags.map((tag) => {
            return { name: tag };
          }),
        };

        $scope.showLoader = true;
        editPostApiService
          .updatePost($stateParams.id, data)
          .then(function (response) {
            $scope.showLoader = false;
            $mdDialog
              .show(
                $mdDialog
                  .alert()
                  .clickOutsideToClose(false)
                  .textContent("Post Edited Successfully!!!")
                  .ok("OK")
                  .openFrom({
                    top: -50,
                    width: 30,
                    height: 80,
                  })
                  .closeTo({ left: 1500 })
              )
              .finally(function () {
                $state.go("postDetail", { id: response.id });
              });
            $state.go("postDetail", { id: response.id });
          })
          .catch(function (error) {
            $scope.showLoader = false;
            $scope.setError(error);
            $scope.fetchPostDetails();
          });
      };
    },
  ]);
})();
