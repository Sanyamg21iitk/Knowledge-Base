"use strict";
(function () {
  angular.module("KnowledgeBase").service("postDetailApiService", [
    "Restangular",
    "APP_CONSTANTS",
    function (Restangular, APP_CONSTANTS) {
      this.fetchPostDetails = function (pk) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, pk).get();
      };

      this.postReaction = function (postId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .all("reaction")
          .post(data);
      };
      this.updateReaction = function (postId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .one("reaction", postId)
          .patch(data);
      };
      this.postCommentReaction = function (postId, commentId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .one("comment", commentId)
          .all("reaction")
          .post(data);
      };
      this.updateCommentReaction = function (postId, commentId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .one("comment", commentId)
          .one("reaction", commentId)
          .patch(data);
      };
      this.addComment = function (postId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .all("comment")
          .post(data);
      };
      this.updateComment = function (postId, commentId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .one("comment", commentId)
          .patch(data);
      };
      this.commentList = function (postId, params) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .all("comment")
          .get("", params);
      };
      this.markAccepted = function (postId, commentId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .one("comment", commentId)
          .patch(data);
      };
      this.createBookmark = function (postId, data) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE, postId)
          .all("bookmark")
          .post(data);
      };
    },
  ]);
})();
