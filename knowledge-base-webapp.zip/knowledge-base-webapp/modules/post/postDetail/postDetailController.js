"use strict";

(function () {
  angular.module("KnowledgeBase").controller("postDetailController", [
    "$scope",
    "postDetailApiService",
    "$state",
    "$stateParams",
    "$rootScope",
    "APP_CONSTANTS",
    "groupBaseApiService",
    "$mdDialog",
    "editPostApiService",
    "$controller",
    function (
      $scope,
      postDetailApiService,
      $state,
      $stateParams,
      $rootScope,
      APP_CONSTANTS,
      groupBaseApiService,
      $mdDialog,
      editPostApiService,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.constants = APP_CONSTANTS;
      $scope.reactionFirst = false;
      $scope.reactionSecond = false;
      $scope.pageNumber = 1;
      $scope.pageNumberOfReply = 1;
      $scope.replies = [];
      $scope.showSeeReplies = [];
      $scope.showList = [];
      $scope.showMoreComment = true;
      $scope.showMoreReply = true;
      $scope.accepted = [];

      $scope.unsubscribe = function () {
        groupBaseApiService
          .unsubscribe({ toggle_unsubscribe_post_id: $stateParams.id })
          .then(function (response) {
            $scope.post.is_subscribed = !$scope.post.is_subscribed;
            $mdDialog.show(
              $mdDialog
                .alert()
                .clickOutsideToClose(true)
                .textContent(
                  "Post" +
                    ($scope.post.is_subscribed
                      ? " Subscribed "
                      : " Unsubscribed ") +
                    "Successfully!!!"
                )
                .ok("OK")
                .openFrom({
                  top: -50,
                  width: 30,
                  height: 80,
                })
                .closeTo({ left: 1500 })
            );
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };
      $scope.bookmarkCreate = function () {
        var confirm = $mdDialog
          .prompt()
          .title("Enter note")
          .textContent("You can check it in your bookmarks tab")
          .placeholder("note")
          .required(true)
          .ok("Create")
          .cancel("Cancel");

        $mdDialog.show(confirm).then(
          function (result) {
            postDetailApiService
              .createBookmark($stateParams.id, { note: result })
              .then(function (response) {
                $scope.bookmark = true;
                $mdDialog.show(
                  $mdDialog
                    .alert()
                    .clickOutsideToClose(true)
                    .title("Success")
                    .textContent("Bookmark created successfully")
                    .ok("OK")
                    .openFrom({
                      top: -50,
                      width: 30,
                      height: 80,
                    })
                    .closeTo({ left: 1500 })
                );
              })
              .catch(function (error) {
                $scope.setError(error);
              });
          },
          function () {}
        );
      };

      $scope.addBounty = function () {
        var confirm = $mdDialog
          .prompt()
          .title("Enter Reward Points")
          .textContent(
            "These points will be deducted from your score when post will be accepted"
          )
          .placeholder("reward")
          .required(true)
          .ok("Add")
          .cancel("Cancel");

        $mdDialog
          .show(confirm)
          .then(
            function (result) {
              var isnum = /^\d+$/.test(result);
              if (!isnum) {
                throw "Enter Number Only";
              }
              editPostApiService
                .updatePost($stateParams.id, { reward: result })
                .then(function (response) {
                  $scope.post.reward = result;
                  $mdDialog.show(
                    $mdDialog
                      .alert()
                      .clickOutsideToClose(true)
                      .title("Success")
                      .textContent("Reward updated successfully")
                      .ok("OK")
                      .openFrom({
                        top: -50,
                        width: 30,
                        height: 80,
                      })
                      .closeTo({ left: 1500 })
                  );
                })
                .catch(function (error) {
                  $scope.setError(error);
                });
            },
            function () {}
          )
          .catch(function (error) {
            $scope.setError(error);
          });
      };

      postDetailApiService
        .fetchPostDetails($stateParams.id)
        .then(function (response) {
          $scope.post = response;
          $scope.publicId =
            APP_CONSTANTS.POST_TYPE[APP_CONSTANTS.POSTS.PUBLIC].id;
          $scope.isOwner = response.user.id == $rootScope.userId;
          $scope.postOwner =
            response.user.first_name + " " + response.user.last_name;
          $scope.postOwnerId = response.user.id;
          if (response.reaction != null) {
            $scope.upvotePost =
              response.reaction == APP_CONSTANTS.REACTION_TYPE.UPVOTE;
            $scope.downvotePost = !$scope.upvotePost;
          }

          if (response.is_bookmarked) {
            $scope.bookmark = true;
          }
        })
        .catch(function (error) {
          $scope.setError(error);
        });

      $scope.moveToEdit = function () {
        $state.go("editPost", { id: $stateParams.id });
      };

      $scope.moveToShare = function () {
        $state.go("sharePost", { id: $stateParams.id });
      };

      $scope.upvote = function () {
        if ($scope.upvotePost || $scope.downvotePost) {
          postDetailApiService
            .updateReaction($stateParams.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.UPVOTE,
            })
            .then(function (response) {
              $scope.post.aggregate_votes += 2;
              $scope.upvotePost = true;
              $scope.downvotePost = false;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        } else {
          postDetailApiService
            .postReaction($stateParams.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.UPVOTE,
            })
            .then(function (response) {
              $scope.post.aggregate_votes += 1;
              $scope.upvotePost = true;
              $scope.downvotePost = false;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        }
      };
      $scope.downvote = function () {
        if ($scope.upvotePost || $scope.downvotePost) {
          postDetailApiService
            .updateReaction($stateParams.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.DOWNVOTE,
            })
            .then(function (response) {
              $scope.post.aggregate_votes -= 2;
              $scope.downvotePost = true;
              $scope.upvotePost = false;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        } else {
          postDetailApiService
            .postReaction($stateParams.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.DOWNVOTE,
            })
            .then(function (response) {
              $scope.post.aggregate_votes -= 1;
              $scope.downvotePost = true;
              $scope.upvotePost = false;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        }
      };

      $scope.upvoteComment = function (comment) {
        if (comment.reaction_type == APP_CONSTANTS.REACTION_TYPE.DOWNVOTE) {
          postDetailApiService
            .updateCommentReaction($stateParams.id, comment.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.UPVOTE,
            })
            .then(function (response) {
              comment.reaction_type = APP_CONSTANTS.REACTION_TYPE.UPVOTE;
              comment.aggregate_votes += 2;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        } else {
          postDetailApiService
            .postCommentReaction($stateParams.id, comment.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.UPVOTE,
            })
            .then(function (response) {
              comment.reaction_type = APP_CONSTANTS.REACTION_TYPE.UPVOTE;
              comment.aggregate_votes += 1;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        }
      };

      $scope.downvoteComment = function (comment) {
        if (comment.reaction_type == APP_CONSTANTS.REACTION_TYPE.UPVOTE) {
          postDetailApiService
            .updateCommentReaction($stateParams.id, comment.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.DOWNVOTE,
            })
            .then(function (response) {
              comment.reaction_type = APP_CONSTANTS.REACTION_TYPE.DOWNVOTE;
              comment.aggregate_votes -= 2;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        } else {
          postDetailApiService
            .postCommentReaction($stateParams.id, comment.id, {
              reaction_type: APP_CONSTANTS.REACTION_TYPE.DOWNVOTE,
            })
            .then(function (response) {
              comment.reaction_type = APP_CONSTANTS.REACTION_TYPE.DOWNVOTE;
              comment.aggregate_votes -= 1;
            })
            .catch(function (error) {
              $scope.setError(error);
            });
        }
      };

      $scope.markAccepted = function (commentId, index) {
        $scope.showMarkAccetedLoader = true;
        postDetailApiService
          .markAccepted($stateParams.id, commentId, { is_accepted: true })
          .then(function (response) {
            $scope.acceptMarked = true;
            $scope.replies = [];
            $scope.commentList();
            $scope.showMarkAccetedLoader = false;
          })
          .catch(function (error) {
            $scope.showMarkAccetedLoader = false;
            $scope.setError(error);
          });
      };
      $scope.markNotAccepted = function (commentId, index) {
        $scope.showMarkNotAccetedLoader = true;
        postDetailApiService
          .markAccepted($stateParams.id, commentId, { is_accepted: false })
          .then(function (response) {
            $scope.acceptMarked = false;
            $scope.replies = [];
            $scope.commentList();
            $scope.showMarkNotAccetedLoader = false;
          })
          .catch(function (error) {
            $scope.showMarkNotAccetedLoader = false;
            $scope.setError(error);
          });
      };

      $scope.editComment = function (commentId, data) {
        $scope.showEditCommentLoader = true;
        postDetailApiService
          .updateComment($stateParams.id, commentId, data)
          .then(function (response) {
            $scope.showEditCommentLoader = false;
            $scope.showEditDiv = false;
            $scope.commentList();
          })
          .catch(function (error) {
            $scope.showEditCommentLoader = false;
            $scope.setError(error);
          });
      };

      $scope.editReply = function (commentId, index, replyId, data) {
        $scope.showEditReplyLoader = true;
        postDetailApiService
          .updateComment($stateParams.id, replyId, data)
          .then(function (response) {
            $scope.pageNumberOfReply = 1;
            $scope.showEditReplyLoader = false;
            $scope.showEditReplyDiv = false;
            $scope.fetchReplies(commentId, index);
          })
          .catch(function (error) {
            $scope.showEditReplyLoader = false;
            $scope.setError(error);
          });
      };

      $scope.comment = function () {
        $scope.showLoader = true;
        postDetailApiService
          .addComment($stateParams.id, { body: $scope.body })
          .then(function (response) {
            $scope.body = "";
            $scope.commentList();
            $scope.showLoader = false;
          })
          .catch(function (error) {
            $scope.setError(error);
            $scope.showLoader = false;
          });
      };

      $scope.commentList = function () {
        postDetailApiService
          .commentList($stateParams.id, { level: 0 })
          .then(function (response) {
            $scope.commentsList = response.results;
            if (response.next == null) {
              $scope.showMoreComment = false;
            } else {
              $scope.showMoreComment = true;
            }
            if (response.count != 0 && response.results[0].is_accepted) {
              $scope.acceptMarked = true;
            }
            if (response.count == 0) {
              $scope.hideCommentsSection = true;
            } else {
              $scope.hideCommentsSection = false;
            }
          })
          .catch(function (error) {
            $scope.showMoreComment = false;
            $scope.setError(error);
          });
      };
      $scope.commentList();

      $scope.showReplyArea = function (index) {
        $scope.showList[index] = true;
      };

      $scope.addReply = function (replyId, replyBody, index) {
        $scope.showReplyLoader = true;
        var data = {
          body: replyBody,
          reply_id: replyId,
        };
        postDetailApiService
          .addComment($stateParams.id, data)
          .then(function (response) {
            $scope.pageNumberOfReply = 1;
            $scope.showReplyLoader = false;
            $scope.noReplies[index] = false;
            $scope.showList = [];
            $scope.fetchReplies(replyId, index);
          })
          .catch(function (error) {
            $scope.showReplyLoader = false;
            $scope.setError(error);
          });
      };
      $scope.noReplies = [];
      $scope.fetchReplies = function (commentId, index) {
        postDetailApiService
          .commentList($stateParams.id, { level: 1, reply_id: commentId })
          .then(function (response) {
            $scope.showList = [];
            $scope.replies[index] = [];
            $scope.replies[index] = response.results;
            $scope.showSeeReplies[index] = true;
            if (response.count == 0) {
              $scope.noReplies[index] = true;
            }
            $scope.showMoreReply = true;
            if (response.next == null) {
              $scope.showMoreReply = false;
            }
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };

      $scope.showMoreComments = function () {
        $scope.showCommentLoader = true;
        postDetailApiService
          .commentList($stateParams.id, {
            level: 0,
            page: $scope.pageNumber + 1,
          })
          .then(function (response) {
            $scope.showCommentLoader = false;
            $scope.pageNumber += 1;
            if (response.next == null) {
              $scope.showMoreComment = false;
            }
            $scope.commentsList = $scope.commentsList.concat(response.results);
          })
          .catch(function (error) {
            $scope.showMoreComment = false;
            $scope.showCommentLoader = false;
            $scope.setError(error);
          });
      };

      $scope.showMoreReplies = function (commentId, index) {
        postDetailApiService
          .commentList($stateParams.id, {
            level: 1,
            reply_id: commentId,
            page: $scope.pageNumberOfReply + 1,
          })
          .then(function (response) {
            $scope.showList = [];
            $scope.pageNumberOfReply += 1;
            $scope.replies[index] = $scope.replies[index].concat(
              response.results
            );
            if (response.count != 0) {
              $scope.showSeeReplies[index] = true;
            }
            if (response.next == null) {
              $scope.showMoreReply = false;
            }
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };
    },
  ]);
})();
