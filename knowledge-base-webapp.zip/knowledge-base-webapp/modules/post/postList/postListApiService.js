"use strict";
(function () {
  angular.module("KnowledgeBase").service("postListApiService", [
    "Restangular",
    "APP_CONSTANTS",
    "$rootScope",
    function (Restangular, APP_CONSTANTS, $rootScope) {
      this.fetchPostList = function (search, page, tag, my_post) {
        return Restangular.one(APP_CONSTANTS.POST_BASE_ROUTE).get({
          search,
          page,
          tag,
          my_post: my_post,
        });
      };

      this.loadTags = function (search, page, my_followed_tags_filter) {
        return Restangular.one(APP_CONSTANTS.TAG_ROUTE).get({
          search,
          page,
          my_tags: "True",
          my_followed_tags: my_followed_tags_filter,
        });
      };

      this.toggleFollowTag = function (data) {
        return Restangular.one(
          APP_CONSTANTS.BASE_USER_ROUTE,
          $rootScope.userId
        ).patch(data);
      };
    },
  ]);
})();
