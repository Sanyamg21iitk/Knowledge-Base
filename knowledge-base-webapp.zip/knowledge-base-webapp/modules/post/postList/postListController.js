"use strict";

(function () {
  angular.module("KnowledgeBase").controller("postListController", [
    "$scope",
    "$state",
    "$stateParams",
    "postListApiService",
    "$mdDialog",
    "APP_CONSTANTS",
    "$controller",
    function (
      $scope,
      $state,
      $stateParams,
      postListApiService,
      $mdDialog,
      APP_CONSTANTS,
      $controller
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      $scope.postQuery = {};
      $scope.data = {};
      $scope.constants = APP_CONSTANTS;
      $scope.data.pageNumber = parseInt($stateParams.page) || 1;
      $scope.postQuery.query = $stateParams.search || "";
      $scope.tag = $stateParams.tag || "";
      $scope.tagSearch = $stateParams.tagSearch || "";
      $scope.tagPageNumber = 1;
      $scope.selectedTags = $scope.tag.split(",").filter((tag) => tag != "");
      $scope.my_post = "False";
      $scope.my_followed_tags = true;
      $scope.tags = [];

      $scope.removeTagFilters = function () {
        $scope.selectedTags = [];
        $scope.refreshTags();
      };


      $scope.show = function () {
        $scope.showButton = true;
      };

      $scope.removeSeletedTag = function (removeTag) {
        $scope.selectedTags = $scope.selectedTags.filter(
          (tag) => tag != removeTag
        );
        $scope.refreshTags();
      };

      $scope.data.urlRefresh = function () {
        $state.go(
          "postList",
          {
            search: $scope.postQuery.query,
            page: $scope.data.pageNumber,
            tag: $scope.tag,
            tagSearch: $scope.tagSearch,
          },
          {
            // prevent the events onStart and onSuccess from firing
            notify: false,
          }
        );
      };

      $scope.hide = function () {
        $scope.showButton = false;
      };
      $scope.moveToCreate = function () {
        $state.go("createPost", {});
      };

      $scope.search = function () {
        $scope.data.pageNumber = 1;
        $scope.data.showPostList();
        $scope.data.urlRefresh();
      };

      $scope.searchTag = function () {
        $scope.tags = [];
        $scope.tagPageNumber = 1;
        $scope.loadTags();
        $scope.data.urlRefresh();
      };

      $scope.loadMore = function () {
        $scope.tagPageNumber += 1;
        $scope.loadTags();
        $scope.data.urlRefresh();
      };

      $scope.refreshTags = function () {
        $scope.tag = $scope.selectedTags.toString();
        $scope.data.showPostList();
        $scope.data.urlRefresh();
      };

      $scope.loadTagPosts = function (tag) {
        $scope.selectedTags.push(tag.name);
        $scope.selectedTags = [...new Set($scope.selectedTags)].filter(
          (tag) => tag != ""
        );
        $scope.refreshTags();
      };

      $scope.toggle_follow_tag = function (tag) {
        postListApiService
          .toggleFollowTag({ toggle_follow_tag_id: tag.id })
          .then(function (response) {
            tag.is_followed = !tag.is_followed;
            $mdDialog.show(
              $mdDialog
                .alert()
                .clickOutsideToClose(true)
                .textContent(
                  "Tag" +
                    (tag.is_followed ? " Followed " : " Unfollowed ") +
                    "Successfully!!!"
                )
                .ok("OK")
                .openFrom({
                  top: -50,
                  width: 30,
                  height: 80,
                })
                .closeTo({ left: 1500 })
            );
          })
          .catch(function (error) {
            $scope.setError(error);
          });
      };

      $scope.loadTags = function () {
        postListApiService
          .loadTags(
            $scope.tagSearch,
            $scope.tagPageNumber,
            $scope.my_followed_tags ? "True" : "False"
          )
          .then((response) => {
            $scope.canLoadMore = response.next;
            $scope.tags = $scope.tags.concat(response.results);
          })
          .catch((error) => {
            $scope.setError(error);
            $scope.tagPageNumber = 1;
            $scope.loadTags();
          });
      };

      $scope.toggleMyFollowedAndAllTags = function () {
        $scope.my_followed_tags = !$scope.my_followed_tags;
        $scope.tags = [];
        $scope.tagPageNumber = 1;
        $scope.loadTags();
      };

      $scope.toggleMyFollowedAndAllTags();

      $scope.data.showPostList = function () {
        $scope.showPageLoader = true;
        postListApiService
          .fetchPostList(
            $scope.postQuery.query,
            $scope.data.pageNumber,
            $scope.tag,
            $scope.my_post
          )
          .then(function (response) {
            $scope.showPageLoader = false;
            $scope.posts = response.results;
            $scope.data.count = response.count;
          })
          .catch(function (error) {
            $scope.showPageLoader = false;
            $scope.setError(error);
            $scope.data.pageNumber = 1;
            $scope.data.showPostList();
            $scope.data.urlRefresh();
          });
      };

      $scope.data.showPostList();
    },
  ]);
})();
