"use strict";

(function () {
  angular.module("KnowledgeBase").controller("sharePostController", [
    "$scope",
    "$controller",
    "createPostApiService",
    "postDetailApiService",
    "groupListApiService",
    "$state",
    "$mdDialog",
    "$stateParams",
    "APP_CONSTANTS",
    function (
      $scope,
      $controller,
      createPostApiService,
      postDetailApiService,
      groupListApiService,
      $state,
      $mdDialog,
      $stateParams,
      APP_CONSTANTS
    ) {
      $controller("commonUtilsController", { $scope: $scope });
      if (!$stateParams.id) {
        return $state.go("postList");
      }
      $scope.constants = APP_CONSTANTS;
      $scope.share = function () {
        var data = {
          title: $scope.post.title,
          description: $scope.post.description,
          tags: $scope.post.tags.map((tag) => {
            return { name: tag };
          }),
          shared_from: $stateParams.id,
          post_type: $scope.post.post_type.id,
        };

        if ($scope.post.group) {
          data.group_id = $scope.post.group.id;
        }
        delete $scope.post.group;
        $scope.showLoader = true;

        createPostApiService
          .createPost(data)
          .then(function (response) {
            $scope.showLoader = false;
            $mdDialog
              .show(
                $mdDialog
                  .alert()
                  .clickOutsideToClose(true)
                  .textContent("Post Shared Successfully!!!")
                  .ok("OK")
                  .openFrom({
                    top: -50,
                    width: 30,
                    height: 80,
                  })
                  .closeTo({ left: 1500 })
              )
              .finally(function () {
                $state.go("postDetail", { id: response.id });
              });
          })
          .catch(function (error) {
            $scope.showLoader = false;
            $scope.setError(error);
            $scope.init();
          });
      };

      $controller("editPostController", { $scope: $scope });
      $controller("createPostController", { $scope: $scope });
    },
  ]);
})();
