# Knowledge Base project setup

### Install pip3

> sudo apt-get install python3-pip

### Install PSQL 10.12

### Create virtual environment

> mkvirtualenv knowledge-base

### Activate virtual environment

> workon knowledge-base

### Install Requirements

> pip3 install -r requirements/base.txt

### clone project from

> git clone git@code.jtg.tools:inductions/induction-2020/4th-batch/knowledge-base.git

### Create database in postgres

### Create a local_setting.py from local_setting.py.template.

### Run migrations

> python manage.py migrate

### Create a Super User

> python manage.py createsuperuser

### Run Server

> python manage.py runserver

### Run Following Command to Deactivate Environment

> deactivate
