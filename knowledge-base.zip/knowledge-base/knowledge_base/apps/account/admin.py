from django.contrib import admin

from apps.account import models as account_models


admin.site.register(account_models.User)
admin.site.register(account_models.Address)
admin.site.register(account_models.EmailVerification)
admin.site.register(account_models.Token)
