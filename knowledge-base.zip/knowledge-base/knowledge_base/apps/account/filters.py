from django_filters import (
    rest_framework as django_filters_backend,
    FilterSet as django_filters_filter_Set
)

from apps.account import models as account_models


class GroupFilter(django_filters_filter_Set):
    group = django_filters_backend.CharFilter(
        'usergroupmodel__group__id', exclude=True
    )
    score = django_filters_backend.RangeFilter()
    created_at = django_filters_backend.IsoDateTimeFromToRangeFilter()

    class Meta:
        model = account_models.User
        fields = ('group', 'score', 'created_at',)
