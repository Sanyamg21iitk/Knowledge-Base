from apps.common import (
    constants as common_constants,
    models as common_models,
    utils as common_utils,
)
from django.contrib.auth import models as auth_models
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext as _


class EmailVerification(common_models.TimeStamp):
    email = models.EmailField(_('email address'), unique=True, null=False)
    activation_key = models.CharField(
        max_length=common_constants.CHAR_FIELD_ACTIVATION_KEY, unique=True
    )
    expired_at = models.DateTimeField(
        _('expiry at'), default=common_utils.expire_time)

    REQUIRED_FIELD = 'email'

    @property
    def is_expired(self):
        return self.expired_at < timezone.now()

    def __str__(self):
        return f'{self.email}'


class UserManager(auth_models.BaseUserManager):
    def _create_user(self, email, password, **extra_fields):
        """
        Creates and saves a User with the given email and password.
        """

        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create(self, email=None, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')

        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(email, password, **extra_fields)


class User(auth_models.AbstractBaseUser, auth_models.PermissionsMixin, common_models.TimeStamp):

    """ User Model for auth and manage account """

    first_name = models.CharField(
        _('first name'), max_length=common_constants.CHAR_FIELD_NAME
    )
    last_name = models.CharField(
        _('last name'), max_length=common_constants.CHAR_FIELD_NAME
    )
    email = models.EmailField(_('email address'), unique=True)
    score = models.PositiveIntegerField(
        default=common_constants.INITIAL_SCORE_USER
    )
    is_staff = models.BooleanField(_('staff status'), default=False)

    EMAIL_FIELD = 'email'
    USERNAME_FIELD = 'email'

    objects = UserManager()

    def get_short_name(self):
        return self.email

    def __str__(self):
        return self.email

    @property
    def token(self):
        # TODO: Will update this code when our system will support mobile app
        token, _ = Token.objects.get_or_create(user=self)
        if _:
            return token.key
        if token.is_expired:
            token.delete()
            return Token.objects.create(user=self).key
        return token.key


class Address(common_models.TimeStamp):

    """ Address Model """

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    adressline_1 = models.CharField(
        _('addressline 1'), max_length=common_constants.CHAR_FIELD_ADDRESS
    )
    adressline_2 = models.CharField(
        _('addressline 2'), max_length=common_constants.CHAR_FIELD_ADDRESS
    )
    city = models.CharField(
        _('city'), max_length=common_constants.CHAR_FIELD_NAME
    )
    state = models.CharField(
        _('state'), max_length=common_constants.CHAR_FIELD_NAME
    )
    zipcode = models.IntegerField(_('zipcode'))

    def __str__(self):
        return f'{self.user} {self.city} {self.state}'


class Token(common_models.TimeStamp):

    """ Token Model """

    key = models.CharField(
        _('key'), max_length=common_constants.CHAR_FIELD_ACTIVATION_KEY
    )
    expired_at = models.DateTimeField(
        _('expiry at'), default=common_utils.expire_time
    )
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, help_text='to specify user'
    )

    @property
    def is_expired(self):
        return self.expired_at < timezone.now()

    @property
    def update_expire(self):
        self.expired_at = common_utils.expire_time()
        self.save()

    def __str__(self):
        return f'{self.user} {self.key}'

    def save(self, *args, **kwargs):
        if not self.key:
            self.key = common_utils.generate_key()
        return super().save(*args, **kwargs)
