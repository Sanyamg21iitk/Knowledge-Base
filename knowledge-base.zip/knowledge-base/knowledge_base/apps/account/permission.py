from rest_framework import (
    exceptions as rest_framework_exceptions,
    permissions as rest_framework_permissions,
)

from apps.account import models as account_models


class IsOwnerOrReadOnly(rest_framework_permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        """
        Return `True` if permission is granted, `False` otherwise.
        """
        if request.method in rest_framework_permissions.SAFE_METHODS:
            return True
        return request.user == obj



class IsValidActivationKey(rest_framework_permissions.BasePermission):
    def has_permission(self, request, view):
        """
        Return `True` if permission is granted, `False` otherwise.
        """
        email_verification_obj = account_models.EmailVerification.objects.filter(
            activation_key=view.kwargs.get('pk')
        )
        if not email_verification_obj.exists():
            raise rest_framework_exceptions.ValidationError(
                'Verify Your Email First'
            )
        if email_verification_obj[0].is_expired:
            email_verification_obj[0].delete()
            raise rest_framework_exceptions.ValidationError(
                'Kindly Verify Email Again'
            )
        return True
