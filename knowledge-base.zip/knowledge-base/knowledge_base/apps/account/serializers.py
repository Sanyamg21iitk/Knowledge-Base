import re
from datetime import datetime, timedelta

from django.contrib.auth import authenticate
from django.contrib.auth.hashers import make_password, check_password
from django.db.models import Q
from django.shortcuts import get_object_or_404

from rest_framework import (
    serializers as rest_framework_serializers,
    exceptions as rest_framework_exceptions,
)

from apps.account import (
    models as user_models,
    tasks as user_tasks,
)
from apps.common import utils as common_utils
from apps.common import constants as common_constants
from apps.group import (
    models as group_models,
)
from apps.post import (
    models as post_models,
    utils as post_utils,
)


class AddressSerializer(rest_framework_serializers.ModelSerializer):

    """ Address Serializer """

    class Meta:
        model = user_models.Address
        fields = (
            'id', 'adressline_1', 'adressline_2', 'city', 'state', 'zipcode', 'user',
        )
        read_only_fields = ('user',)


class BaseUserSerializer(rest_framework_serializers.ModelSerializer):

    class Meta:
        model = user_models.User
        fields = (
            'id', 'email', 'password', 'first_name', 'last_name', 'score', 'last_login', 'created_at',
        )
        extra_kwargs = {
            'password': {'write_only': True, 'min_length': common_constants.PASSWORD_LENGTH},
            'last_login': {'write_only': True},
            'is_active': {'write_only': True},
            'is_superuser': {'write_only': True}
        }

    def validate_password(self, password):
        # Passowrd Lemgth in field validators
        if re.search('[A-Z]', password) is None:
            raise rest_framework_serializers.ValidationError(
                'missing_upper_case'
            )
        if re.search('[a-z]', password) is None:
            raise rest_framework_serializers.ValidationError(
                'missing_lower_case'
            )
        if re.search('[0-9]', password) is None:
            raise rest_framework_serializers.ValidationError('missing_digit')
        return password


class UserSerializer(BaseUserSerializer):
    """ User Serializer """

    address = AddressSerializer(required=False)
    toggle_unsubscribe_group_id = rest_framework_serializers.PrimaryKeyRelatedField(
        queryset=group_models.Group.objects.all(), write_only=True, required=False
    )
    toggle_unsubscribe_post_id = rest_framework_serializers.PrimaryKeyRelatedField(
        queryset=post_models.Post.objects.all(),  write_only=True, required=False
    )
    toggle_follow_tag_id = rest_framework_serializers.PrimaryKeyRelatedField(
        queryset=post_models.Tag.objects.all(), write_only=True, required=False
    )

    class Meta(BaseUserSerializer.Meta):
        fields = BaseUserSerializer.Meta.fields + (
            'address', 'toggle_unsubscribe_group_id', 'toggle_unsubscribe_post_id', 'toggle_follow_tag_id',
        )

    def validate_toggle_unsubscribe_group_id(self, group):
        get_object_or_404(
            group_models.UserGroupModel, user=self.context['request'].user, group=group
        )
        return group

    def validate_toggle_unsubscribe_post_id(self, post):
        if not post_utils.can_see_post(self.context['request'].user.id, post.id):
            raise rest_framework_serializers.ValidationError(
                'Permission Denied for you to access this post'
            )
        return post

    """ Update User Details and Address(if exists otherwise make a new one) """

    def update(self, instance, validated_data):
        toggle_follow_tag_id = validated_data.pop('toggle_follow_tag_id', None)
        toggle_unsubscribe_group_id = validated_data.pop(
            'toggle_unsubscribe_group_id', None
        )
        toggle_unsubscribe_post_id = validated_data.pop(
            'toggle_unsubscribe_post_id', None
        )
        if toggle_follow_tag_id:
            if instance.tag_set.filter(id=toggle_follow_tag_id.id).exists():
                instance.tag_set.remove(
                    toggle_follow_tag_id
                )
            else:
                instance.tag_set.add(
                    toggle_follow_tag_id
                )

        if toggle_unsubscribe_group_id:
            user_group_model = instance.usergroupmodel_set.get(
                group_id=toggle_unsubscribe_group_id.id
            )
            if user_group_model.notification_prefrence == common_constants.NOTIFICATION_TYPES.FREQUENT:
                user_group_model.notification_prefrence = common_constants.NOTIFICATION_TYPES.NONE
            else:
                user_group_model.notification_prefrence = common_constants.NOTIFICATION_TYPES.FREQUENT
            user_group_model.save()

        if toggle_unsubscribe_post_id:
            if instance.unsubscribed_users_posts.filter(id=toggle_unsubscribe_post_id.id).exists():
                instance.unsubscribed_users_posts.remove(
                    toggle_unsubscribe_post_id
                )
            else:
                instance.unsubscribed_users_posts.add(
                    toggle_unsubscribe_post_id
                )

        if 'address' in validated_data:
            try:
                super().update(
                    instance.address, validated_data.pop('address')
                )
            except:
                user_models.Address.objects.create(
                    **validated_data.pop('address'), user=instance
                )

        return super().update(instance, validated_data)


class EmailVerificationSerializer(rest_framework_serializers.ModelSerializer):
    class Meta:
        model = user_models.EmailVerification
        fields = ('email',)

    def create(self, validated_data):
        validated_data['activation_key'] = '{key}'.format(
            key=common_utils.generate_key()
        )
        email_verification_instance = super(
            EmailVerificationSerializer, self
        ).create(validated_data)
        user_tasks.send_activation_email.delay(
            validated_data['activation_key'],
            validated_data['email']
        )
        return email_verification_instance


# change serialiser methiod field and givve source


class UserTokenSerializer(UserSerializer):
    """
    Serializer for returning token along with user data
    """

    token = rest_framework_serializers.CharField()

    class Meta(UserSerializer.Meta):
        fields = UserSerializer.Meta.fields + ('token',)


class LoginSerializer(rest_framework_serializers.Serializer):
    email = rest_framework_serializers.EmailField()
    password = rest_framework_serializers.CharField()

    def validate(self, data):
        """
        Authenticate user
        """
        try:
            user = user_models.User.objects.get(
                email=data.get('email').strip().lower()
            )
        except:
            raise rest_framework_serializers.ValidationError(
                {'error': 'User not found '}
            )

        if check_password(data['password'], user.password):
            data['user'] = user
            return data
        else:
            raise rest_framework_serializers.ValidationError(
                {'error': 'Password not matched'}
            )


class UserReportSerializer(UserSerializer):
    # member of how many groups
    group_count = rest_framework_serializers.IntegerField(read_only=True)
    # number of groups whose owner is this user
    group_owner_count = rest_framework_serializers.IntegerField(read_only=True)
    # number of posts user created
    posts_created_count = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts in which user commented
    commented_posts_count = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts in which user has reacted
    reacted_posts_count = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts in which user's comment has marked accepted
    accepted_comments_count = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts user created having given tag
    posts_created_count_with_tag = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts in which user's comment has marked accepted
    accepted_comments_count_with_tag = rest_framework_serializers.IntegerField(
        read_only=True
    )

    class Meta(UserSerializer.Meta):
        model = user_models.User
        fields = UserSerializer.Meta.fields + \
            (
                'group_count', 'group_owner_count', 'posts_created_count', 'posts_created_count_with_tag',
                'commented_posts_count', 'reacted_posts_count', 'accepted_comments_count', 'accepted_comments_count_with_tag',
            )
