from celery import task

from apps.common import utils as common_utils


@task
def send_activation_email(activation_key, to_email):
    """
    method to fill details of the email and user to whom email will be send and send it
    """

    subject = 'Activate your email'
    context = {
        'activation_url': 'http://localhost:8080/#!/register/{activation_key}'.format(
            activation_key=activation_key
        )
    }
    template = 'activation_key'
    common_utils.send_email(subject, template, context, [to_email, ])
