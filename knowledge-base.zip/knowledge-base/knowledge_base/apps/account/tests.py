from django.urls import reverse

from rest_framework import (
    status as rest_framework_status,
    test as rest_framework_test,
)

from apps.account import models as account_models


# class EmailVerification(rest_framework_test.APITestCase):
#     def setUp(self):
#         self.verify_email = account_models.EmailVerification.objects.create(
#             email='shivam', activation_key='theactivationkey', is_verified=True
#         )


class SignupTests(rest_framework_test.APITestCase):
    def setUp(self):
        """method for setting up the test fixture before running it."""

        """ create a valid user """
        self.user = account_models.User.objects.create(
            email='sumit@gmail.com', first_name='sumit', last_name='lohan', password='sumit'
        )

        """ create a verified Email """
        account_models.EmailVerification.objects.create(
            email='shivam@gmail.com', activation_key='theactivationkey', is_verified=True
        )

    def tearDown(self):
        """method for deconstructing the test fixture after testing it."""
        account_models.EmailVerification.objects.get(
            email='shivam@gmail.com').delete()
        account_models.User.objects.get(
            email='sumit@gmail.com').delete()

    def test_create_valid_email_user(self):
        """
        Ensure we can create a new user object.
        """
        url = reverse('user-list')
        data = {
            'email': 'shivam@gmail.com',
            'first_name': 'Shivam',
            'last_name': 'Garg',
            'password': 'Shivam@123'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(
            response.status_code,
            rest_framework_status.HTTP_201_CREATED
        )
        self.assertEqual(response.data['email'], data['email'])

    def test_create_repeated_email(self):
        """
        Ensure we can't create user that already exists.
        """
        url = reverse('user-list')
        data = {
            'email': 'sumit@gmail.com',
            'first_name': 'sumit',
            'last_name': 'lohan',
            'password': 'sumit'
        }

        response = self.client.post(url, data, format='json')
        self.assertEqual(
            response.status_code,
            rest_framework_status.HTTP_400_BAD_REQUEST
        )

    def test_create_unverified_email_user(self):
        """
        Ensure we can't create a User with unverified email address.
        """
        url = reverse('user-list')
        data = {
            'email': 'ayush@gmail.com',
            'first_name': 'ayush',
            'last_name': 'ayush',
            'password': 'ayush'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(
            response.status_code,
            rest_framework_status.HTTP_400_BAD_REQUEST
        )


class LoginTestCase(rest_framework_test.APITestCase):
    def setUp(self):
        self.user = account_models.User.objects.create(
            email='sumit@gmail.com', first_name='sumit', last_name='lohan'
        )
        self.user.set_password('123')
        self.user.save()

    def tearDown(self):
        """method for deconstructing the test fixture after testing it."""
        account_models.User.objects.get(
            email='sumit@gmail.com').delete()

    def test_login_right_password(self):
        """
        Ensure existing user with right password can login
        """
        url = reverse('signin')
        data = {
            'email': "sumit@gmail.com",
            'password': '123'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(
            response.status_code,
            rest_framework_status.HTTP_202_ACCEPTED
        )

    def test_login_wrong_password(self):
        """
        Ensure existing user with wrong pass can't login
        """
        url = reverse('signin')
        data = {
            'email': "sumit@gmail.com",
            'password': '321'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(
            response.status_code,
            rest_framework_status.HTTP_400_BAD_REQUEST
        )

    def test_login_user_not_exist(self):
        """
        test to check if user not exist
        """
        url = reverse('signin')
        data = {
            'email': "shivam@gmail.com",
            'password': '123'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(
            response.status_code,
            rest_framework_status.HTTP_400_BAD_REQUEST
        )
