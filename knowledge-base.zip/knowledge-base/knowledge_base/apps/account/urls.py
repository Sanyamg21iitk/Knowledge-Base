from django.conf.urls import include, url

from rest_framework import routers

from apps.account import views as account_views
from apps.post import views as post_views

router = routers.SimpleRouter()

router.register('user', account_views.UserView, basename='user')
router.register('email', account_views.EmailVerificationView, basename='email')


urlpatterns = [
    url(
        r'report/(?P<id>\d+)/$', account_views.UserReportView.as_view({'get': 'retrieve'}), name='report'
    ),
    url(r'^signin/$', account_views.LoginView.as_view(), name='signin'),
    url(r'^signout/$', account_views.LogoutView.as_view(), name='signout'),
    url(
        r'user/bookmarks/$',
        post_views.BookmarkView.as_view(
            {'get': 'list'}
        ),
        name='bookmarks'
    ),
    url(r'', include(router.urls)),
]
