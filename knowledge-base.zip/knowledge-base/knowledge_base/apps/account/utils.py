from django.db.models import OuterRef

from rest_framework import exceptions as rest_framework_exceptions

from apps.account import models as account_models
from apps.common import utils as common_utils
from apps.post import models as post_models


def tag_filter(tag_param):
    posts = post_models.Post.objects.prefetch_related('tag').filter(
        user=OuterRef('pk')
    )
    comments = post_models.Comment.objects.prefetch_related('post__tag').filter(
        user=OuterRef('pk'),  is_accepted=True
    )
    for tag in common_utils.tag_list(tag_param):
        posts = posts.filter(tag__name=tag)
        comments = comments.filter(post__tag__name=tag)
    return posts, comments


def get_email_from_activation_key(activation_key):
    """
    Return `True` if permission is granted, `False` otherwise.
    """
    email_verification_obj = account_models.EmailVerification.objects.filter(
        activation_key=activation_key
    )
    if not email_verification_obj.exists():
        raise rest_framework_exceptions.ValidationError(
            'Verify Your Email First'
        )
    if email_verification_obj.first().is_expired:
        raise rest_framework_exceptions.ValidationError(
            'Kindly Verify Email Again'
        )
    return email_verification_obj.first()
