from django.core.mail import send_mail
from django.contrib.auth.hashers import make_password, check_password
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.db.models import Count, Q, Subquery, OuterRef, IntegerField, Case, When, Sum, Value
from django.forms.models import model_to_dict

from rest_framework import (
    generics as rest_framework_generics,
    status as rest_framework_status,
    viewsets as rest_framework_viewsets,
    views as rest_framework_views,
    response as rest_framework_response,
    filters as rest_framework_filters,
    permissions as rest_framework_permissions,
    pagination as rest_framework_pagination,
)
from django_filters import rest_framework as django_filters_backend

from apps.account import (
    models as account_models,
    serializers as account_serializers,
    permission as account_permissions,
    filters as account_filters,
    utils as account_utils,
)
from apps.common import (
    constants as common_constants,
    expression as common_expressions,
    utils as common_utils,
)
from apps.group import (
    models as group_models,
)
from apps.post import (
    models as post_models,
)


class UserView(rest_framework_viewsets.ModelViewSet):
    """
    Save Data of user on sign up
    """
    queryset = account_models.User.objects.all()
    serializer_class = account_serializers.UserSerializer
    permission_classes = (
        rest_framework_permissions.IsAuthenticated, account_permissions.IsOwnerOrReadOnly,
    )
    filter_backends = [
        django_filters_backend.DjangoFilterBackend,
        rest_framework_filters.OrderingFilter,
        rest_framework_filters.SearchFilter
    ]
    filter_class = account_filters.GroupFilter
    ordering_fields = ('created_at', 'score',)
    search_fields = ('email', 'first_name',)
    pagination_class = rest_framework_pagination.PageNumberPagination
    ordering = ('-created_at',)

    def create(self, request, *args, **kwargs):
        email_instance = account_utils.get_email_from_activation_key(
            request.data.pop('activation_key')
        )
        request.data['email'] = email_instance.email
        serializer = account_serializers.UserSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        email_instance.delete()
        return rest_framework_response.Response(
            account_serializers.UserTokenSerializer(user).data,
            status=rest_framework_status.HTTP_201_CREATED
        )

    def get_permissions(self):
        if self.action == 'create':
            self.permission_classes = ()
        return super().get_permissions()


class EmailVerificationView(rest_framework_viewsets.ModelViewSet):
    """
    View for work on email confirmation model
    """
    queryset = account_models.EmailVerification.objects.all()
    serializer_class = account_serializers.EmailVerificationSerializer
    lookup_field = 'activation_key'
    lookup_url_kwarg = 'pk'
    authentication_classes = ()
    http_method_names = ('post', 'get',)
    permission_classes = ()

    def get_permissions(self):
        if self.action == 'retrieve':
            self.permission_classes = (
                account_permissions.IsValidActivationKey,
            )
        return super().get_permissions()


class LoginView(rest_framework_views.APIView):
    """
    Login API for user
    """
    http_method_names = ('post',)
    authentication_classes = ()

    def post(self, request):
        """
        create token when user successfully authenticated
        """
        serializer = account_serializers.LoginSerializer()
        data = serializer.validate(data=request.data)
        token = data.get('user').token
        serializer = account_serializers.UserTokenSerializer(data.get('user'))
        return rest_framework_response.Response(serializer.data, rest_framework_status.HTTP_202_ACCEPTED)


class LogoutView(rest_framework_views.APIView):
    """
    Logout API for user
    """
    # use delete Here
    permission_classes = (rest_framework_permissions.IsAuthenticated,)
    http_method_names = ('post',)

    def post(self, request):
        account_models.Token.objects.get(user=request.user).delete()
        return rest_framework_response.Response(status=rest_framework_status.HTTP_200_OK)


class UserReportView(
    rest_framework_viewsets.mixins.RetrieveModelMixin,
    rest_framework_viewsets.GenericViewSet
):
    serializer_class = account_serializers.UserReportSerializer
    permission_classes = (rest_framework_permissions.IsAuthenticated,)
    lookup_field = 'id'

    def get_queryset(self):
        queryset = account_models.User.objects.all()
        if not self.request.GET.get('tag'):
            queryset = queryset.filter(id=self.kwargs.get(self.lookup_field)).annotate(
                group_count=Count('usergroupmodel'),
                group_owner_count=common_expressions.SubQueryCount(
                    group_models.UserGroupModel.objects.filter(
                        role=common_constants.ROLE.OWNER, user=OuterRef('pk')
                    ).values('user')
                ),
                posts_created_count=common_expressions.SubQueryCount(
                    post_models.Post.objects.filter(
                        user=OuterRef('pk')
                    ).values('user')
                ),
                commented_posts_count=Subquery(
                    post_models.Comment.objects.filter(
                        user=OuterRef('pk')
                    ).values('user').annotate(commented_posts_count=Count('post__id', distinct=True)).values('commented_posts_count'),
                    output_field=IntegerField(),
                ),
                reacted_posts_count=common_expressions.SubQueryCount(
                    post_models.Reaction.objects.filter(
                        user=OuterRef('pk'), content_type_id=common_constants.CONTENT_TYPE_POST
                    ).values('user')
                ),
                accepted_comments_count=common_expressions.SubQueryCount(
                    post_models.Comment.objects.filter(
                        user=OuterRef('pk'), is_accepted=True
                    ).values('user')
                ),
            )
        else:
            posts, comments = account_utils.tag_filter(
                self.request.GET.get('tag')
            )
            queryset = queryset.annotate(
                posts_created_count_with_tag=common_expressions.SubQueryCount(
                    posts.values('user')
                ),
                accepted_comments_count_with_tag=common_expressions.SubQueryCount(
                    comments.values('user')
                ),
            )
        return queryset
