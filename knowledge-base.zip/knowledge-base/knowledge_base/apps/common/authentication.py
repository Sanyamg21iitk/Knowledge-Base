from django.utils.translation import gettext as _

from rest_framework.authentication import TokenAuthentication
from rest_framework import exceptions

from apps.account import models as account_models


class CustomTokenAuthentication(TokenAuthentication):
    model = account_models.Token

    def authenticate_credentials(self, key):
        model = self.get_model()
        try:
            token = model.objects.select_related('user').get(key=key)
            if token.is_expired:
                token.delete()
                raise exceptions.AuthenticationFailed(_('Token Expired.'))
            else:
                token.update_expire
        except:
            raise exceptions.AuthenticationFailed(_('Invalid token.'))

        if not token.user.is_active:
            raise exceptions.AuthenticationFailed(
                _('User inactive or deleted.')
            )

        return (token.user, token)
