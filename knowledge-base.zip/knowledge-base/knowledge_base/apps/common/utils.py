import os
import binascii
from datetime import timedelta

from django.conf import settings
from django.core.mail import EmailMultiAlternatives, send_mail
from django.utils import timezone
from django.template.loader import render_to_string as renderer

from apps.common import constants as common_constants


def expire_time():
    return timezone.now()+timedelta(
        minutes=common_constants.EXPIRE_TOKEN__EMAIL_IN_MINUTES
    )


def generate_key():
    return binascii.hexlify(os.urandom(common_constants.ACTIVATION_KEY)).decode()


def send_email(subject, template, context, to):
    """
    method to fill details of the email and user to whom email will be send and send it
    """
    msg = EmailMultiAlternatives(
        subject=subject, body=renderer('{template}.txt'.format(template=template), context), from_email=settings.EMAIL_HOST_USER, bcc=to
    )
    msg.attach_alternative(
        renderer(
            '{template}.html'.format(template=template), context
        ),
        "text/html"
    )
    msg.send()


def tag_list(obj):
    return [tag.strip() for tag in obj.split(',')]
