from django.db import models
from django.utils.translation import gettext as _

from apps.account import models as account_models
from apps.common import (
    constants as common_constants,
    models as common_models,
)


class Group(common_models.TimeStamp):

    """ Group Model """

    name = models.CharField(
        _('name'), max_length=common_constants.CHAR_FIELD_NAME
    )
    short_description = models.CharField(
        _('short description'), max_length=common_constants.CHAR_FIELD_SHORT_DESCRIPTION, blank=True
    )
    members = models.ManyToManyField(
        account_models.User, through='UserGroupModel'
    )

    def __str__(self):
        return f'{self.id} {self.name}'


class UserGroupModel(common_models.TimeStamp):

    """ UserGroup Model to store user and group with accociated role """
    role = models.SmallIntegerField(
        _('role'), choices=common_constants.ROLE_CHOICES
    )
    notification_prefrence = models.SmallIntegerField(
        _('notification_prefrence'), choices=common_constants.NOTIFICATION_TYPES_CHOICES, default=common_constants.NOTIFICATION_TYPES.FREQUENT
    )
    group = models.ForeignKey(Group, on_delete=models.CASCADE)
    user = models.ForeignKey(account_models.User, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('group', 'user',)

    def __str__(self):
        return f'{self.user} {self.group} {self.role} {self.notification_prefrence}'
