from rest_framework import permissions as rest_framework_permissions

from apps.common import constants as common_constants
from apps.group import models as group_models


class GroupPermission(rest_framework_permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        """ only members can get data """
        if request.method in rest_framework_permissions.SAFE_METHODS:
            return group_models.UserGroupModel.objects.filter(
                group_id=obj.id, user_id=request.user.id
            ).exists()

        """ Admins and Owner can modify Group values """
        return group_models.UserGroupModel.objects.filter(
            group_id=obj.id, user_id=request.user.id, role__in=common_constants.ADMIN_OWNER_ROLES
        ).exists()


class IsAdminOrOwner(rest_framework_permissions.BasePermission):
    def has_permission(self, request, view):
        """ True if requesting user is Admin """
        return group_models.UserGroupModel.objects.filter(
            role__in=common_constants.ADMIN_OWNER_ROLES, user_id=request.user.id,
            group_id=view.kwargs['group_id'],
        ).exists()


class IsOwner(rest_framework_permissions.BasePermission):
    def has_permission(self, request, view):
        """ True if requesting user is Admin """
        return group_models.UserGroupModel.objects.filter(
            role=common_constants.ROLE.OWNER, user_id=request.user.id,
            group_id=view.kwargs['group_id'],
        ).exists()


class IsCurrentUserOrAdminOrOwner(rest_framework_permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        """ True if requesting user is Owner and obj user is also Owner: a Owner can be deleted By a Owner only """
        if obj.role == common_constants.ROLE.OWNER:
            return group_models.UserGroupModel.objects.filter(
                role=common_constants.ROLE.OWNER,
                user_id=request.user.id, group_id=view.kwargs['group_id']
            ).exists()

        """ True if requesting user is Owner or Admin or itself """
        return obj.user == request.user or group_models.UserGroupModel.objects.filter(
            role__in=common_constants.ADMIN_OWNER_ROLES,
            user_id=request.user.id, group_id=view.kwargs['group_id']
        ).exists()


class IsGroupMember(rest_framework_permissions.BasePermission):
    def has_permission(self, request, view):
        """ check if user is member of group """
        return group_models.UserGroupModel.objects.filter(
            user_id=request.user.id, group_id=view.kwargs['group_id']
        ).exists()
