from django.db import transaction
from django.utils import timezone

from rest_framework import (
    serializers as rest_framework_serializers,
    exceptions as rest_framework_exceptions,
    status as rest_framework_status,
)

from datetime import timedelta

from apps.account import (
    models as account_models,
    serializers as account_serializers
)
from apps.group import (
    models as group_models,
    utils as group_utils,
)
from apps.common import constants as common_constants
from apps.post import models as post_models


class GroupSerializer(rest_framework_serializers.ModelSerializer):
    """Group Serializer"""

    users = rest_framework_serializers.PrimaryKeyRelatedField(
        queryset=account_models.User.objects.all(),  write_only=True, many=True
    )
    role = rest_framework_serializers.IntegerField(read_only=True)
    is_subscribed = rest_framework_serializers.BooleanField(read_only=True)

    class Meta:
        model = group_models.Group
        fields = (
            'id', 'name', 'short_description', 'users', 'role', 'is_subscribed', 'created_at',
        )

    def create(self, validated_data):
        users = validated_data.pop('users', [])
        with transaction.atomic():
            group = group_models.Group.objects.create(**validated_data)
            userlist = [
                group_models.UserGroupModel(
                    user=user,
                    group=group,
                    role=common_constants.ROLE.MEMBER
                ) for user in users
            ]
            userlist.append(
                group_models.UserGroupModel(
                    user=self.context['request'].user,
                    group=group,
                    role=common_constants.ROLE.OWNER
                )
            )
            user_added = group_models.UserGroupModel.objects.bulk_create(
                userlist
            )
            transaction.on_commit(
                lambda: group_utils.send_group_create_notification(
                    users, group
                )
            )
        return group


class UserGroupSerializer(rest_framework_serializers.ModelSerializer):
    user_id = rest_framework_serializers.PrimaryKeyRelatedField(
        queryset=account_models.User.objects.all(), source='user', write_only=True
    )
    group_id = rest_framework_serializers.PrimaryKeyRelatedField(
        queryset=group_models.Group.objects.all(), source='group', write_only=True
    )
    user = account_serializers.BaseUserSerializer(read_only=True)

    class Meta:
        model = group_models.UserGroupModel
        fields = ('role', 'user', 'group', 'user_id', 'group_id',)
        read_only_fields = ('group',)

    def create(self, validated_data):
        instance = super().create(validated_data)
        group_utils.send_group_member_add_notification(instance)
        return instance

    def update(self, instance, validated_data):
        if instance.role == common_constants.ROLE.OWNER:
            user_count = group_utils.get_group_owner_member_count(
                instance.group.id
            )
            if user_count['owner'] < 2:
                raise rest_framework_exceptions.ValidationError(
                    detail={'error': 'Please mark an user to Owner before Changing youe role'}, code=rest_framework_status.HTTP_400_BAD_REQUEST
                )
        user_group_instance = super(UserGroupSerializer, self).update(
            instance, validated_data
        )
        group_utils.send_group_member_update_role_notification(
            user_group_instance
        )
        return user_group_instance


class GroupReportSerializer(GroupSerializer):
    # number of members of the group
    member_count = rest_framework_serializers.IntegerField(read_only=True)
    # number of owners
    owner_count = rest_framework_serializers.IntegerField(read_only=True)
    # list of owners
    owner_list = rest_framework_serializers.SerializerMethodField()
    # number of posts created in the group
    posts_created_count = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts that has marked accepted
    accepted_comments_count = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts created in the group with given tag
    posts_created_count_with_tag = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of posts that has marked accepted having given tag
    accepted_comments_count_with_tag = rest_framework_serializers.IntegerField(
        read_only=True
    )
    # number of active users by post creation
    active_users_by_post_creation = rest_framework_serializers.SerializerMethodField()
    # number of active users by commenting on post
    active_users_by_comment_posting = rest_framework_serializers.SerializerMethodField()
    # number of active users by reacting on post and comment
    active_users_by_reaction = rest_framework_serializers.SerializerMethodField()

    def get_owner_list(self, obj):
        query = group_models.UserGroupModel.objects.prefetch_related('user').filter(
            group=obj, role=common_constants.ROLE.OWNER
        )
        user_list = []
        for usergroupmodel in query:
            user_list.append(usergroupmodel.user)
        return account_serializers.BaseUserSerializer(user_list, many=True).data

    def get_active_users_by_post_creation(Self, obj):
        posts = obj.post_set.filter(
            created_at__gt=timezone.now() - timedelta(
                minutes=common_constants.ACTIVE_USER_CONSTRAINT_TIME_IN_MINUTES
            )
        )
        users = []
        for post in posts:
            users.append(post.user)
        return account_serializers.BaseUserSerializer(set(users), many=True).data

    def get_active_users_by_comment_posting(Self, obj):
        comments = post_models.Comment.objects.filter(
            post__group=obj,
            created_at__gt=timezone.now()-timedelta(
                minutes=common_constants.ACTIVE_USER_CONSTRAINT_TIME_IN_MINUTES
            ),
            is_accepted=True
        )
        users = []
        for comment in comments:
            users.append(comment.user)
        return account_serializers.BaseUserSerializer(set(users), many=True).data

    def get_active_users_by_reaction(Self, obj):
        posts = post_models.Post.objects.filter(
            group=obj, reaction__isnull=False, created_at__gt=timezone.now()-timedelta(
                minutes=common_constants.ACTIVE_USER_CONSTRAINT_TIME_IN_MINUTES
            )
        )
        comments = post_models.Comment.objects.filter(
            post__group=obj,
            created_at__gt=timezone.now()-timedelta(
                minutes=common_constants.ACTIVE_USER_CONSTRAINT_TIME_IN_MINUTES
            ),
            reaction__isnull=False
        )
        users = []
        for comment in comments:
            users.append(comment.user)
        for post in posts:
            users.append(post.user)
        return account_serializers.BaseUserSerializer(set(users), many=True).data

    class Meta(GroupSerializer.Meta):
        model = group_models.Group
        fields = GroupSerializer.Meta.fields + (
            'member_count', 'owner_count', 'owner_list', 'accepted_comments_count', 'posts_created_count', 'accepted_comments_count_with_tag',
            'posts_created_count_with_tag', 'active_users_by_post_creation', 'active_users_by_comment_posting', 'active_users_by_reaction',
        )
