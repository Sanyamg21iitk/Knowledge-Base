from celery import task

from apps.common import utils as common_utils


@task
def send_group_join_email(group_name, group_id, to_email, user_name):
    """
    method to send notification to users being added to a Group
    """
    subject = 'Your are Added to {group_name}'.format(group_name=group_name)
    context = {
        'group_url': 'http://localhost:8080/#!/user/groups/{group_id}'.format(
            group_id=group_id
        ),
        'group_name': group_name.capitalize(),
        'user_name': user_name.capitalize()
    }
    template = 'user_added_to_group'

    common_utils.send_email(subject, template, context, [to_email, ])


@task
def remove_from_group_notification(group_name, user_name, to_email):
    """ send Notification to user when he is removed from a Group """
    subject = 'Your are Removed from {group_name}'.format(
        group_name=group_name
    )
    context = {
        'group_name': group_name.capitalize(),
        'user_name': user_name.capitalize()
    }
    template = 'removed_from_group'

    common_utils.send_email(subject, template, context, [to_email, ])


@task
def role_update_group(group_name, group_role, user_name, to_email):
    """ send notification to a user when his/her role in a group Changes """
    subject = 'Your Role Changed: {group_name}'.format(group_name=group_name)
    context = {
        'group_name': group_name.capitalize(),
        'group_role': group_role.capitalize(),
        'user_name': user_name.capitalize()
    }
    template = 'role_change_group'

    common_utils.send_email(subject, template, context, [to_email, ])
