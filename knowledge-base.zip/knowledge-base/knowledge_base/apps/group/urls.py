from django.conf.urls import include, url

from rest_framework import routers

from apps.group import views as group_views

router = routers.SimpleRouter()

router.register('', group_views.GroupView, basename='group')
router.register(
    '(?P<group_id>\d+)/members',
    group_views.GroupUsersView, basename='group-user'
)

urlpatterns = [
    url(
        r'report/(?P<id>\d+)/$', group_views.GroupReportView.as_view({'get': 'retrieve'}), name='report'
    ),
    url(r'', include(router.urls)),
]
