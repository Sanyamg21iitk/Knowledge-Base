from django.db import (
    models as django_models,
)

from apps.common import (
    constants as common_constants,
    utils as common_utils,
)
from apps.group import (
    models as group_models,
    tasks as group_tasks
)
from apps.post import models as post_models


def get_group_owner_member_count(group_id):
    """ 
    returns no. of owners and members in a group.
    """
    return group_models.UserGroupModel.objects.filter(
        group_id=group_id,
    ).aggregate(
        owner=django_models.Count(
            django_models.Case(
                django_models.When(
                    role=common_constants.ROLE.OWNER, then=1
                )
            )
        ),
        member=django_models.Count('user')
    )


def send_group_create_notification(users, group):
    """ 
    send notifications to users being added to the newly created group.
    """
    for user in users:
        group_tasks.send_group_join_email.delay(
            group.name, group.id, user.email, user.first_name
        )


def send_group_member_add_notification(instance):
    """ 
    send notification to user when user is added to a group.
    """
    group_tasks.send_group_join_email.delay(
        instance.group.name, instance.group.id, instance.user.email, instance.user.first_name
    )


def send_group_member_update_role_notification(user_group_instance):
    """ 
    send notification to user if user's role gets updated in a group.
    """
    group_tasks.role_update_group.delay(
        user_group_instance.group.name, common_constants.ROLES_DICT[
            user_group_instance.role
        ], user_group_instance.user.first_name, user_group_instance.user.email
    )


def send_remove_from_group_notification(group_name, instance):
    """ 
    send a notification to user if a user leaves the group or gets removed by Admin/Owner of group.
    """
    group_tasks.remove_from_group_notification.delay(
        group_name, instance.user.first_name, instance.user.email
    )


def tag_filter(tag_param):
    posts = post_models.Post.objects.prefetch_related('tag').filter(
        group=django_models.OuterRef('pk')
    )
    comments = post_models.Comment.objects.prefetch_related('post__tag').filter(
        post__group=django_models.OuterRef('pk'),  is_accepted=True
    )
    for tag in common_utils.tag_list(tag_param):
        posts = posts.filter(tag__name=tag)
        comments = comments.filter(post__tag__name=tag)
    return posts, comments
