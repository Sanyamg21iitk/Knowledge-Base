from django.db import transaction
from django.db.models import F, Case, When, BooleanField, Exists, OuterRef, Subquery, IntegerField, Count

from rest_framework import (
    filters as rest_framework_filters,
    permissions as rest_framework_permissions,
    viewsets as rest_framework_viewsets,
    exceptions as rest_framework_exceptions
)

from apps.account import (
    models as account_models,
    serializers as account_serializers,
)
from apps.common import (
    constants as common_constants,
    expression as common_expressions,
    utils as common_utils,
)
from apps.group import (
    models as group_models,
    serializers as group_serializers,
    permission as group_permissions,
    utils as group_utils,
)
from apps.post import(
    models as post_models,
)


class GroupView(rest_framework_viewsets.ModelViewSet):
    """ Group View : for creating, updating and getting info abount the group  """
    serializer_class = group_serializers.GroupSerializer
    permission_classes = (rest_framework_permissions.IsAuthenticated,)
    filter_backends = (
        rest_framework_filters.OrderingFilter,
        rest_framework_filters.SearchFilter,
    )
    ordering_fields = ('created_at',)
    search_fields = ('name',)
    http_method_names = ('get', 'post', 'patch',)

    def get_queryset(self):
        query = group_models.Group.objects.filter(usergroupmodel__user_id=self.request.user.id).annotate(
            role=F('usergroupmodel__role'),
            is_subscribed=Exists(
                group_models.UserGroupModel.objects.filter(
                    group_id=OuterRef('pk'), user_id=self.request.user.id, notification_prefrence=1
                )
            ),
        )
        return query

    def get_permissions(self):
        if self.action != 'create':
            self.permission_classes += (group_permissions.GroupPermission, )
        return super().get_permissions()


class GroupUsersView(rest_framework_viewsets.ModelViewSet):
    """ Group User View: for managing relation between a group and user and their roles """
    serializer_class = group_serializers.UserGroupSerializer
    permission_classes = (rest_framework_permissions.IsAuthenticated,)
    lookup_field = 'user_id'
    filter_backends = (
        rest_framework_filters.OrderingFilter,
        rest_framework_filters.SearchFilter
    )
    ordering_fields = ('user__created_at',)
    search_fields = ('user__first_name', 'user__email',)
    http_method_names = ('get', 'post', 'patch', 'delete',)

    def perform_destroy(self, instance):
        group_name = instance.group.name
        if instance.role == common_constants.ROLE.OWNER:
            with transaction.atomic():
                user_count = group_utils.get_group_owner_member_count(
                    instance.group.id
                )
                if user_count['member'] > 1:
                    if user_count['owner'] < 2:
                        raise rest_framework_exceptions.ValidationError(
                            detail={
                                'error': 'Please mark an user to Owner before leaving the group'
                            },
                        )
                else:
                    instance.group.delete()
                instance.delete()
        else:
            instance.delete()
        group_utils.send_remove_from_group_notification(group_name, instance)

    def get_queryset(self):
        return group_models.UserGroupModel.objects.select_related("user").filter(
            group_id=self.kwargs.get('group_id')
        )

    def get_serializer(self, *args, **kwargs):
        """ if an array is passed, set serializer to many """
        if 'data' in kwargs:
            if isinstance(kwargs.get('data', {}), list):
                kwargs['many'] = True
                for data in kwargs['data']:
                    data['group_id'] = self.kwargs['group_id']
            else:
                kwargs['data']['group_id'] = self.kwargs['group_id']
        return super().get_serializer(*args, **kwargs)

    def get_permissions(self):
        if self.action == 'partial_update':
            self.permission_classes += (group_permissions.IsOwner,)
        elif self.action == 'destroy':
            self.permission_classes += (
                group_permissions.IsCurrentUserOrAdminOrOwner,
            )
        elif self.action in ['list', 'retrieve']:
            self.permission_classes += (group_permissions.IsGroupMember,)
        else:
            self.permission_classes += (group_permissions.IsAdminOrOwner,)
        return super().get_permissions()


class GroupReportView(
    rest_framework_viewsets.mixins.RetrieveModelMixin,
    rest_framework_viewsets.GenericViewSet
):
    serializer_class = group_serializers.GroupReportSerializer
    permission_classes = (
        rest_framework_permissions.IsAuthenticated, group_permissions.GroupPermission,
    )
    lookup_field = 'id'

    def get_queryset(self):
        queryset = group_models.Group.objects.filter(usergroupmodel__user_id=self.request.user.id).annotate(
            role=F('usergroupmodel__role'),
            is_subscribed=Exists(
                group_models.UserGroupModel.objects.filter(
                    group_id=OuterRef('pk'), user_id=self.request.user.id, notification_prefrence=1
                )
            ),
        )
        if not self.request.GET.get('tag'):
            queryset = queryset.annotate(
                member_count=common_expressions.SubQueryCount(
                    group_models.UserGroupModel.objects.filter(
                        group=OuterRef('pk')
                    ).values('group')
                ),
                owner_count=common_expressions.SubQueryCount(
                    group_models.UserGroupModel.objects.filter(
                        group=OuterRef('pk'), role=common_constants.ROLE.OWNER
                    ).values('group')
                ),
                posts_created_count=common_expressions.SubQueryCount(
                    post_models.Post.objects.filter(
                        group=OuterRef('pk'), shared_from__isnull=True
                    ).values('group')
                ),
                accepted_comments_count=common_expressions.SubQueryCount(
                    post_models.Comment.objects.filter(
                        post__group=OuterRef('pk'), is_accepted=True
                    ).values('post__group')
                ),
            )
        else:
            posts, comments = group_utils.tag_filter(
                self.request.GET.get('tag')
            )
            queryset = queryset.annotate(
                posts_created_count_with_tag=common_expressions.SubQueryCount(
                    posts.values('user')
                ),
                accepted_comments_count_with_tag=common_expressions.SubQueryCount(
                    comments.values('user')
                ),
            )
        return queryset
