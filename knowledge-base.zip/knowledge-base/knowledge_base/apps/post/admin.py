from django.contrib import admin

from apps.post import models as post_models

admin.site.register(post_models.Post)
admin.site.register(post_models.Reaction)
admin.site.register(post_models.Tag)
admin.site.register(post_models.Comment)
admin.site.register(post_models.Bookmark)
