from django.apps import AppConfig


class PostConfig(AppConfig):
    name = 'apps.post'
