from django.db.models import Q, Count
import django_filters

from apps.common import constants as common_constants
from apps.group import models as group_models
from apps.post import models as post_models


class MyTagFilter(django_filters.FilterSet):
    my_tags = django_filters.BooleanFilter(method='filter_my_tags')
    my_followed_tags = django_filters.BooleanFilter(
        method='filter_my_followed_tags'
    )

    def filter_my_tags(self, queryset, name, value):
        if value:
            return queryset.filter(
                post__in=post_models.Post.objects.filter(
                    Q(post_type=common_constants.POST_TYPE.PUBLIC)
                    | Q(
                        group__in=group_models.Group.objects.filter(
                            usergroupmodel__user_id=self.request.user.id
                        )
                    )
                )
            )
        return queryset

    def filter_my_followed_tags(self, queryset, name, value):
        if value:
            return queryset.filter(
                user=self.request.user
            )
        return queryset

    class Meta:
        model = post_models.Tag
        fields = ('my_tags', 'my_followed_tags',)


class MyPostFilter(django_filters.FilterSet):
    my_post = django_filters.BooleanFilter(method='filter_my_post')
    tag = django_filters.CharFilter(method='filter_tag')

    def filter_my_post(self, queryset, name, value):
        if value:
            return queryset.filter(user_id=self.request.user.id)
        return queryset

    def filter_tag(self, queryset, name, value):
        if value:
            tags = [tag.strip() for tag in value.split(',')]
            for tag in tags:
                queryset = queryset.filter(tag__name=tag)
        return queryset

    class Meta:
        model = post_models.Post
        fields = ('my_post', 'tag',)
