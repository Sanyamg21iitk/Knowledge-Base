from django.contrib.contenttypes.fields import GenericForeignKey, GenericRelation
from django.contrib.contenttypes.models import ContentType

from django.db import models
from django.utils.translation import gettext as _

from apps.account import models as account_model
from apps.common import (
    models as common_models,
    constants as common_constants
)
from apps.group import models as group_model


class Reaction(common_models.TimeStamp):

    """ Reaction Model """

    reaction_type = models.IntegerField(
        _('reaction type'), choices=common_constants.REACTION_CHOICES
    )
    user = models.ForeignKey(
        account_model.User, help_text='tells which user reacted', on_delete=models.CASCADE
    )
    limit = models.Q(app_label='post', model='post') | models.Q(
        app_label='post', model='comment'
    )
    content_type = models.ForeignKey(
        ContentType, on_delete=models.CASCADE, limit_choices_to=limit
    )
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    class Meta:
        unique_together = ('user', 'content_type', 'object_id',)

    def __str__(self):
        return f'{self.user} {self.reaction_type}'


class Post(common_models.TimeStamp):

    """ Post Model """

    title = models.CharField(
        _('title'), max_length=common_constants.CHAR_FIELD_NAME
    )
    # remove max length from text field
    description = models.CharField(
        _('description'), max_length=common_constants.CHAR_FIELD_DESCRIPTION, blank=True
    )
    post_type = models.IntegerField(
        _('type'), choices=common_constants.POST_CHOICES
    )
    shared_from = models.OneToOneField(
        'self', help_text='tells the parent post of this post', null=True, blank=True, on_delete=models.SET_NULL
    )
    reward = models.IntegerField(
        _('reward'), default=common_constants.INITIAL_POST_REWARD
    )
    user = models.ForeignKey(
        account_model.User, related_name='user_posts', help_text='owner of the post', on_delete=models.CASCADE
    )
    group = models.ForeignKey(
        group_model.Group, null=True, blank=True, on_delete=models.CASCADE
    )

    unsubscribed_user = models.ManyToManyField(
        account_model.User, related_name='unsubscribed_users_posts', blank=True
    )

    reaction = GenericRelation(Reaction)

    def __str__(self):
        return f'{self.user} {self.title}'


class Tag(common_models.TimeStamp):

    """ Tag Model """

    name = models.CharField(
        _('name'), max_length=common_constants.CHAR_FIELD_TAG, unique=True,
    )
    post = models.ManyToManyField(
        Post, help_text='relate many posts to many tags', blank=True
    )
    user = models.ManyToManyField(
        account_model.User, help_text='a user can follow many tags and vice versa', blank=True
    )

    @property
    def count_posts(self):
        return len(self.post)

    def __str__(self):
        return f'{self.name} {self.user} {self.post}'


class Comment(common_models.TimeStamp):

    """ Comment Model """

    body = models.CharField(
        _('body'), max_length=common_constants.CHAR_FIELD_SHORT_DESCRIPTION
    )
    level = models.IntegerField(
        _('level'), default=common_constants.INITIAL_COMMENT_LEVEL
    )
    is_accepted = models.BooleanField(_('is accepted'), default=False)
    reply = models.ForeignKey(
        'self', null=True, blank=True, on_delete=models.SET_NULL
    )
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    user = models.ForeignKey(
        account_model.User, on_delete=models.SET_NULL, null=True
    )
    reaction = GenericRelation(Reaction)

    def __str__(self):
        return f'{self.body} {self.user} {self.post}'


class Bookmark(common_models.TimeStamp):

    """ Bookmark Model """

    note = models.CharField(
        _('note'), max_length=common_constants.CHAR_FIELD_SHORT_DESCRIPTION, blank=True
    )
    post = models.ForeignKey(
        Post, help_text='tells on which post bookmark is done', on_delete=models.CASCADE
    )
    user = models.ForeignKey(
        account_model.User, help_text='Bookmark of a user', on_delete=models.CASCADE
    )

    class Meta:
        unique_together = ('user', 'post',)

    def __str__(self):
        return f'{self.user} {self.post}'
