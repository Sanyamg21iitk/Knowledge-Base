from django.db.models import Q
from django.shortcuts import get_object_or_404

from rest_framework import exceptions as rest_framework_exceptions
from rest_framework import permissions as rest_framework_permissions

from apps.common import constants as common_constants
from apps.group import models as group_models
from apps.post import (
    models as post_models,
    utils as post_utils,
)


class CanAddReaction(rest_framework_permissions.BasePermission):
    """ check if user can react to the post """

    def has_permission(self, request, view):
        return post_utils.can_see_post(request.user.id, view.kwargs.get('post_id'))


class IsOwner(rest_framework_permissions.BasePermission):
    """ check if user is owner of the post """

    def has_permission(self, request, view):
        return post_utils.is_post_owner(view.kwargs.get('pk'), request.user.id)


class ReactionValidationPermission(rest_framework_permissions.BasePermission):
    """ check if user is reacting to the valid post and comment"""

    def has_permission(self, request, view):
        if view.kwargs.get('comment_id'):
            comment = get_object_or_404(
                post_models.Comment, id=view.kwargs.get(
                    'comment_id'
                )
            )
            if comment.post.id != int(view.kwargs.get('post_id')):
                raise rest_framework_exceptions.ValidationError(
                    'Post and comment not matched'
                )
            if comment.user == request.user:
                raise rest_framework_exceptions.ValidationError(
                    'Cannot react on your own comment'
                )
        else:
            post = get_object_or_404(
                post_models.Post, id=view.kwargs.get('post_id')
            )
            if post.user == request.user:
                raise rest_framework_exceptions.ValidationError(
                    'Cannot react on your own post'
                )
        return True
