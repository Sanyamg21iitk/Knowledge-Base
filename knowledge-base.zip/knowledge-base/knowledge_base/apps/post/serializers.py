from django.contrib.contenttypes.models import ContentType as django_content_type
from django.db.models import Q
from django.shortcuts import get_object_or_404

from rest_framework import serializers, exceptions

from apps.account import (
    models as account_models,
    serializers as account_serializers,
)
from apps.common import constants as common_constants

from apps.group import (
    models as group_models,
    serializers as group_serializers,
)
from apps.post import (
    models as post_models,
    utils as post_utils,
)


class PostBaseSerializer(serializers.ModelSerializer):
    """Post Serializer"""

    class Meta:
        model = post_models.Post
        fields = ('id', 'title',)


class BookmarkSerializer(serializers.ModelSerializer):
    post = PostBaseSerializer(read_only=True)

    class Meta:
        model = post_models.Bookmark
        fields = ('id', 'note', 'post', 'created_at',)

    def create(self, validated_data):
        validated_data.update({
            'user': self.context['request'].user,
            'post_id': self.context['view'].kwargs.get('post_id')
        })
        return post_models.Bookmark.objects.create(**validated_data)


class TagSerializer(serializers.ModelSerializer):

    """ Tag Serializer : serailise whole Tag Data """

    name = serializers.CharField()
    count = serializers.IntegerField(read_only=True)
    is_followed = serializers.BooleanField(read_only=True)

    class Meta:
        model = post_models.Tag
        fields = ('id', 'name', 'count', 'is_followed',)


class BaseTagSerializer(serializers.ModelSerializer):

    """ Base Tag Serializer: Serialise Name of Tag """
    class Meta:
        model = post_models.Tag
        fields = ('name',)


class PostSerializer(PostBaseSerializer):
    """Post Serializer"""
    group_id = serializers.PrimaryKeyRelatedField(
        queryset=group_models.Group.objects.all(),
        source='group', write_only=True, required=False, allow_null=True,
    )
    user = account_serializers.BaseUserSerializer(read_only=True)
    tags = TagSerializer(many=True, write_only=True)
    tag = BaseTagSerializer(many=True, read_only=True, source='tag_set')
    group = group_serializers.GroupSerializer(read_only=True)
    is_subscribed = serializers.BooleanField(read_only=True)
    is_bookmarked = serializers.BooleanField(read_only=True, default=False)
    aggregate_votes = serializers.IntegerField(read_only=True)

    class Meta(PostBaseSerializer.Meta):
        model = post_models.Post
        fields = PostBaseSerializer.Meta.fields + (
            'description', 'post_type', 'user', 'reward', 'group', 'group_id',
            'tags', 'tag', 'shared_from', 'is_bookmarked', 'aggregate_votes', 'is_subscribed', 'created_at',
        )

    def validate(self, data):
        if self.context['request'].method == 'POST':
            if data.get('post_type') == common_constants.POST_TYPE.PUBLIC:
                data['group'] = None
            elif data.get('post_type') == common_constants.POST_TYPE.PRIVATE:
                get_object_or_404(
                    group_models.UserGroupModel, user=self.context['request'].user,
                    group=data.get('group')
                )
                return data

        if self.context['request'].method == 'PATCH' or self.context['request'].method == 'PUT':
            if 'post_type' in data or 'group' in data:
                raise exceptions.ValidationError('Can\'t update visibility')
        return data

    def validate_reward(self, reward):
        if self.context['request'].method == 'POST':
            raise exceptions.ValidationError(
                "You can't add reward on post creation"
            )
        post = post_models.Post.objects.get(
            id=self.context['view'].kwargs.get('pk')
        )
        if post.user != self.context['request'].user:
            raise exceptions.ValidationError(
                "You can't update other person's post reward"
            )
        if post.comment_set.filter(is_accepted=True).exists():
            raise exceptions.ValidationError(
                "This post is already marked as accepted"
            )
        if not reward > post.reward:
            raise exceptions.ValidationError(
                'Reward must be greater than your previous reward i.e. {previous_reward}'.format(
                    previous_reward=post.reward
                )
            )
        if post.user.score < (reward - post.reward):
            raise exceptions.ValidationError(
                'Reward must be less than or equal to your score'
            )
        return reward

    def create(self, validated_data):
        validated_data.update({
            'user': self.context['request'].user,
        })
        tags = validated_data.pop('tags', [])
        post = post_models.Post.objects.create(**validated_data)
        post_utils.create_tag_post_entry(tags, post, False)
        if post.group:
            post_utils.send_new_group_post_notification(
                post,  self.context['request'].user
            )
        return post

    def update(self, instance, validated_data):
        if 'reward' in validated_data:
            user = instance.user
            user.score -= validated_data.get('reward') - instance.reward
            user.save()
        tags = validated_data.pop('tags', [])
        post_utils.create_tag_post_entry(tags, instance, True)
        return super(PostSerializer, self).update(instance, validated_data)


class PostReactionSerializer(PostSerializer):
    """Post Reaction Serializer"""
    reaction = serializers.SerializerMethodField()

    def get_reaction(self, obj):
        try:
            return obj.reaction.get(user_id=self.context.get('request').user.id).reaction_type
        except:
            pass
        return None

    class Meta(PostSerializer.Meta):
        fields = PostSerializer.Meta.fields + ('reaction', )


class ReactionSerializer(serializers.ModelSerializer):
    """Reaction Serializer"""

    user = account_serializers.BaseUserSerializer(read_only=True)

    class Meta:
        model = post_models.Reaction
        fields = ('id', 'reaction_type', 'user',)

    def validate(self, data):
        """validate if user is reacting to the same comment whose id he sent by url"""
        if self.context['view'].kwargs.get('comment_id'):
            comment = get_object_or_404(
                post_models.Comment, id=self.context['view'].kwargs.get(
                    'comment_id'
                )
            )

            if comment.post.id != int(self.context['view'].kwargs.get('post_id')):
                raise serializers.ValidationError(
                    'Post and comment not matched'
                )

            if comment.user == self.context['request'].user:
                raise serializers.ValidationError(
                    'Cannot react on your own comment'
                )
        else:
            post = get_object_or_404(
                post_models.Post, id=self.context['view'].kwargs.get('post_id')
            )
            if post.user == self.context['request'].user:
                raise serializers.ValidationError(
                    'Cannot react on your own post'
                )
        return data

    def create(self, validated_data):
        if self.context['view'].kwargs.get('comment_id'):
            content_type = django_content_type.objects.get_for_model(
                post_models.Comment
            )
            object_id = self.context.get('view').kwargs.get('comment_id')
        else:
            content_type = django_content_type.objects.get_for_model(
                post_models.Post
            )
            object_id = self.context.get('view').kwargs.get('post_id')
        validated_data.update({
            'user': self.context['request'].user,
            'content_type': content_type,
            'object_id': object_id,
        })
        instance = post_models.Reaction.objects.create(**validated_data)
        post_utils.send_reaction_notification(
            instance, self.context['request'].user
        )
        return instance

    def update(self, instance, validated_data):
        instance = super(ReactionSerializer, self).update(
            instance, validated_data
        )
        post_utils.send_reaction_notification(
            instance, self.context['request'].user
        )
        return instance


class CommentSerializer(serializers.ModelSerializer):
    """ Comment Serializer """
    reply_id = serializers.PrimaryKeyRelatedField(
        queryset=post_models.Comment.objects.all(), source='reply', write_only=True, required=False
    )
    user = account_serializers.BaseUserSerializer(read_only=True)
    aggregate_votes = serializers.IntegerField(read_only=True)

    class Meta:
        model = post_models.Comment
        fields = (
            'id', 'body', 'is_accepted', 'reply', 'reply_id', 'user', 'created_at', 'aggregate_votes',
        )

    def validate_body(self, body):
        if self.context['request'].method == 'PATCH' or self.context['request'].method == 'PUT':
            try:
                comment = post_models.Comment.objects.get(
                    pk=self.context['view'].kwargs.get('pk')
                )
            except:
                raise serializers.ValidationError(
                    'Not a valid id to edit comment'
                )
            if comment.user != self.context['request'].user:
                raise serializers.ValidationError(
                    'Cant edit comment'
                )
        return body

    def validate_is_accepted(self, value):
        if self.context['request'].method == 'POST':
            raise exceptions.ValidationError('cant mark accepted')

        """Check comment id is related to the given post id"""
        if not post_models.Comment.objects.filter(
            id=self.context['view'].kwargs.get('pk'),
            level=0, post__user=self.context['request'].user
        ).exists():
            raise serializers.ValidationError(
                'Not a valid comment to mark accepted'
            )

        comment = post_models.Comment.objects.get(
            id=self.context['view'].kwargs.get('pk')
        )

        if comment.user == comment.post.user:
            raise serializers.ValidationError(
                'You cannot accept your own comment'
            )

        if not value and not comment.is_accepted:
            raise serializers.ValidationError(
                'Comment is already un accepted'
            )

        """Check if any comment is not marked accepted"""
        if value and post_models.Comment.objects.filter(
            post_id=self.context['view'].kwargs.get('post_id'), is_accepted=True
        ).exists():
            raise exceptions.ValidationError(
                'one comment already marked accepted on this post'
            )
        return value

    def validate_reply_id(self, reply):
        get_object_or_404(
            post_models.Comment, pk=reply.id, level=0
        )
        return reply

    def create(self, validated_data):
        validated_data.update({
            'user': self.context['request'].user,
            'post_id': self.context['view'].kwargs.get('post_id'),
            'level': 1 if 'reply' in validated_data else 0
        })
        comment = post_models.Comment.objects.create(**validated_data)
        post_utils.send_comment_and_reply_notification(
            comment, self.context['request'].user
        )
        return comment

    def update(self, instance, validated_data):
        if instance.reply:
            instance = super(CommentSerializer, self).update(
                instance, validated_data
            )
        else:
            if 'is_accepted' in validated_data:
                user_instance = instance.user
                user_instance.score += (common_constants.COMMENT_ACCEPTED_SCORE + instance.post.reward) if validated_data.get(
                    'is_accepted'
                ) else -(common_constants.COMMENT_ACCEPTED_SCORE + instance.post.reward)
                user_instance.save()
            else:
                if instance.is_accepted:
                    raise exceptions.ValidationError(
                        'Can\'t update accepted comment'
                    )
            instance = super(CommentSerializer, self).update(
                instance, validated_data
            )
            if instance.is_accepted and 'is_accepted' in validated_data:
                post_utils.send_comment_accepted_notification(instance)
        return instance


class CommentReactionSerializer(CommentSerializer):
    """Comment Reaction Serializer"""
    reaction_type = serializers.SerializerMethodField()
    upvotes = serializers.IntegerField(read_only=True)
    downvotes = serializers.IntegerField(read_only=True)
    aggregate_votes = serializers.IntegerField(read_only=True)

    def get_reaction_type(self, obj):
        try:
            return obj.reaction.get(user_id=self.context.get('request').user.id).reaction_type
        except:
            pass
        return None

    class Meta(CommentSerializer.Meta):
        fields = CommentSerializer.Meta.fields + (
            'reaction_type', 'upvotes', 'downvotes', 'aggregate_votes',
        )
