from datetime import timedelta

from celery import task
from celery.task.schedules import crontab
from celery.decorators import periodic_task

from apps.common import (
    utils as common_utils,
    constants as common_constants,
)
from apps.post import utils as post_utils


@task
def new_post_notification(post_title, post_id, group_name, post_user, user):
    """
    method to send notification to users When new Post is created by a User
    """
    subject = 'New post: {post_title}'.format(
        post_title=post_title.capitalize()
    )
    context = {
        'post_url': 'http://localhost:8080/#!/user/posts/{post_id}'.format(
            post_id=post_id
        ),
        'group_name': group_name.capitalize(),
        'post_title': post_title.capitalize(),
        'post_user': post_user.capitalize(),
        'user_name': user['first_name'].capitalize()
    }
    template = 'new_post'

    common_utils.send_email(subject, template, context, [user['email'], ])


@task
def comment_notification(comment_user, post_id, comment_body, user, post_title):
    """
    method to send notification to user when any user comments on a post
    """
    subject = 'New Comment: {post_title}'.format(
        post_title=post_title.capitalize()
    )
    context = {
        'post_url': 'http://localhost:8080/#!/user/posts/{post_id}'.format(
            post_id=post_id
        ),
        'comment_body': comment_body.capitalize(),
        'comment_user': comment_user.capitalize(),
        'user_name': user['first_name'].capitalize()
    }
    template = 'comment_notification'

    common_utils.send_email(subject, template, context, [user['email'], ])


@task
def comment_reply_notification(reply_user, post_id, reply_body, user_name, to_email, comment_body):
    """
    method to send notification to user when any user replies on comment of other user.
    """
    subject = '{reply_user} has replied to your comment'.format(
        reply_user=reply_user.capitalize()
    )
    context = {
        'post_url': 'http://localhost:8080/#!/user/posts/{post_id}'.format(
            post_id=post_id
        ),
        'reply_body': reply_body.capitalize(),
        'comment_body': comment_body.capitalize(),
        'comment_user': reply_user.capitalize(),
        'user_name': user_name.capitalize()
    }
    template = 'comment_reply_notification'

    common_utils.send_email(subject, template, context, [to_email, ])


@task
def reaction_notification(reaction_type, post_id, content_body, content_type, reaction_user, user_name, to_email, post_title):
    """
    method to send notification to users When a post or comment has any reaction
    """
    subject = '{reaction_user} reacted on Your {content_type}: {post_title}'.format(
        reaction_user=reaction_user.capitalize(), content_type=content_type, post_title=post_title
    )
    context = {
        'post_url': 'http://localhost:8080/#!/user/posts/{post_id}'.format(
            post_id=post_id
        ),
        'reaction_type': reaction_type.capitalize(),
        'content_type': content_type.capitalize(),
        'reaction_user': reaction_user.capitalize(),
        'content_body': content_body.capitalize(),
        'user_name': user_name.capitalize()
    }
    template = 'reaction_notification'

    common_utils.send_email(subject, template, context, [to_email, ])


@task
def accepted_comment_notification(user_name, comment_user, post_id, post_title):
    """
    method to send notification to user whose comment got accepted on a Post
    """
    subject = 'Comment Accepted: {post_title}'.format(post_title=post_title)
    context = {
        'post_url': 'http://localhost:8080/#!/user/posts/{post_id}'.format(
            post_id=post_id
        ),
        'user_name': user_name.capitalize()
    }
    template = 'comment_accepted_notification'

    common_utils.send_email(subject, template, context, [comment_user, ])


@task
def no_comment_for_long_notification(user_name, post_user, post_id, post_title):
    """
    send Notification to a User when his Post has no accepted comment and has no comments in 1 month
    """
    subject = 'No Comments for 1 Month: {post_title}'.format(
        post_title=post_title)
    context = {
        'post_url': 'http://localhost:8080/#!/user/posts/{post_id}'.format(
            post_id=post_id
        ),
        'user_name': user_name.capitalize(),
        'post_title': post_title.capitalize()
    }
    template = 'posts_with_no_comment_for_long_notification'

    common_utils.send_email(subject, template, context, [post_user, ])


@periodic_task(run_every=timedelta(minutes=common_constants.ACTIVE_USER_CONSTRAINT_TIME_IN_MINUTES))
def send_no_comments_for_long_notification():
    """ Periodic task to check and send Notification for unanswered posts """
    post_utils.posts_with_no_comment_for_long()
