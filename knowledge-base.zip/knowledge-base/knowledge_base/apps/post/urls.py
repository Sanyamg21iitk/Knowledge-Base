from django.conf.urls import include, url

from rest_framework import routers

from apps.post import views as post_views

router = routers.SimpleRouter()

router.register('tags', post_views.TagView, basename='tag')
router.register(
    '(?P<post_id>\d+)/reaction', post_views.ReactionView, basename='reaction'
)
router.register(
    '(?P<post_id>\d+)/comment/(?P<comment_id>\d+)/reaction', post_views.ReactionView, basename='comment-reaction'
)
router.register(
    '(?P<post_id>\d+)/comment', post_views.CommentView, basename='comment'
)
router.register('', post_views.PostView, basename='post')


urlpatterns = [
    url(
        r'(?P<post_id>\d+)/bookmark/$', post_views.BookmarkView.as_view(
            {'post': 'create'}
        )
    ),
    url(
        r'(?P<post_id>\d+)/bookmark/(?P<pk>\d+)/$', post_views.BookmarkView.as_view(
            {'patch': 'update'}
        )
    ),
    url(r'', include(router.urls)),
]
