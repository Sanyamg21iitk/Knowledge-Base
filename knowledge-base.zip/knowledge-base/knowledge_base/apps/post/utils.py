from datetime import timedelta
from django.utils import timezone
from django.db import transaction
from django.db.models import Q, Subquery, OuterRef

from apps.account import models as account_models
from apps.common import constants as common_constants
from apps.post import (
    models as post_models,
    tasks as post_tasks,
)
from apps.group import models as group_models


def create_tag_post_entry(tags, post, is_update):
    """
    create and update the tag post relation between a tag and a post.
    """
    with transaction.atomic():
        if is_update:
            post.tag_set.clear()

        existing_tags = post_models.Tag.objects.filter(
            name__in=[tag['name'] for tag in tags]
        )

        new_tags_list = [
            post_models.Tag(name=tag.strip().lower()) for tag in [tag['name'] for tag in tags] if tag not in [existing_tag.name for existing_tag in existing_tags]
        ]

        new_tags = post_models.Tag.objects.bulk_create(new_tags_list)
        tags = list(existing_tags) + new_tags
        tag_to_post_links = []

        for tag in tags:
            post_tag = post_models.Tag.post.through(
                tag_id=tag.id, post_id=post.id
            )
            tag_to_post_links.append(post_tag)

        post_models.Tag.post.through.objects.bulk_create(tag_to_post_links)


def is_post_owner(post_id, user_id):
    return post_models.Post.objects.filter(id=post_id, user_id=user_id).exists()


def get_group_subscribed_users(group_id, user_id):
    """ 
    returns list of users(email, first name) which are member of group
    except those who have unsubscribed from group notifications
    """
    return account_models.User.objects.filter(
        Q(usergroupmodel__group__id=group_id), ~Q(id=user_id),
        Q(usergroupmodel__notification_prefrence=common_constants.NOTIFICATION_TYPES.FREQUENT)
    ).values('email', 'first_name')


def get_comment_notification_users(post_id, user_id, post_owner):
    """ 
    returns list of users(email, first name) which have commented on the post and to the Owner of post
    except those users which have unsubscribed from the post notifications.
    """
    return list(
        account_models.User.objects.filter(
            id__in=account_models.User.objects.filter(
                Q(comment__post__id=post_id),
                ~Q(id=user_id), ~Q(id=post_owner),
                Q(usergroupmodel__notification_prefrence=common_constants.NOTIFICATION_TYPES.FREQUENT)
            )
        ).values('email', 'first_name')
    )


def posts_with_no_comment_for_long():
    """ 
    send a notification to the post owner if a post have no accepted comment 
    and there is no comment in last 30 days on post
    and repeat this in interval of 30 days
    """
    posts = post_models.Post.objects.select_related('user').filter(
        ~Q(
            comment__created_at__gt=timezone.now()
            -
            timedelta(
                minutes=common_constants.ACTIVE_USER_CONSTRAINT_TIME_IN_MINUTES
            )
        ),
        ~Q(comment__is_accepted=True)
    ).annotate(
        latest_comment_date=Subquery(
            post_models.Comment.objects.filter(
                post=OuterRef('pk')
            ).order_by('-created_at').values('created_at')[:1]
        )
    )
    for post in posts:
        time = int(
            (
                timezone.now() - post.latest_comment_date if post.latest_comment_date
                else timezone.now() - post.created_at
            ).total_seconds()/60/60/24/30
        )
        if time % 30 == 0:
            post_tasks.no_comment_for_long_notification.delay(
                post.user.first_name, post.user.email, post.id, post.title
            )


def send_reaction_notification(instance, user):
    """ 
    sends post/comment reaction notifications to the user
    """
    if str(instance.content_type) == common_constants.CONTENT_TYPE_POST_STR:
        post_tasks.reaction_notification.delay(
            common_constants.REACTIONS_DICT[instance.reaction_type], instance.content_object.id, instance.content_object.title, str(
                instance.content_type), user.first_name,  instance.content_object.user.first_name, instance.content_object.user.email, instance.content_object.title
        )
    else:
        post_tasks.reaction_notification.delay(
            common_constants.REACTIONS_DICT[instance.reaction_type], instance.content_object.post.id, instance.content_object.body, str(
                instance.content_type), user.first_name, instance.content_object.user.first_name, instance.content_object.user.email, instance.content_object.post.title
        )


def send_comment_and_reply_notification(comment, comment_user):
    """ 
    sends comment/reply notifications to user
    """
    if comment.reply:
        post_tasks.comment_reply_notification.delay(
            comment_user.first_name, comment.post.id, comment.body,  comment.reply.user.first_name,  comment.reply.user.email, comment.reply.body
        )
    else:
        users = get_comment_notification_users(
            comment.post.id, comment_user.id, comment.post.user.id
        )

        """ Add Post Owner to Notification list if anybody else comments than Owner"""
        if comment_user.id != comment.post.user.id:
            users.append({
                'email': comment.post.user.email,
                'first_name': comment.post.user.first_name
            })
        for user in users:
            post_tasks.comment_notification.delay(
                comment_user.first_name, comment.post.id, comment.body, user, comment.post.title
            )


def send_comment_accepted_notification(instance):
    """ 
    sends notification to the user if user's comment got accepted.
    """
    post_tasks.accepted_comment_notification.delay(
        instance.user.first_name, instance.user.email, instance.post.id, instance.post.title
    )


def send_new_group_post_notification(post, post_user):
    """ 
    sends notification to group members when there is new post posted in the group.
    """
    users = get_group_subscribed_users(
        post.group.id, post_user.id
    )
    for user in users:
        post_tasks.new_post_notification.delay(
            post.title, post.id, post.group.name, post_user.email, user
        )


def can_see_post(user_id, post_id):
    return post_models.Post.objects.filter(
        Q(post_type=common_constants.POST_TYPE.PUBLIC) |
        (
            Q(
                post_type=common_constants.POST_TYPE.PRIVATE, group__in=group_models.Group.objects.filter(
                    usergroupmodel__user_id=user_id
                )
            )
        )
    ).filter(pk=post_id).exists()
