from django.db.models import Q, F, Case, When, Value, BooleanField, Subquery, OuterRef, IntegerField, Sum, Count, Exists
from django.shortcuts import get_object_or_404

from django_filters.rest_framework import DjangoFilterBackend

from django_filters import rest_framework as django_filters_backend
from rest_framework import (
    generics as rest_framework_generics,
    status as rest_framework_status,
    viewsets as rest_framework_viewsets,
    views as rest_framework_views,
    response as rest_framework_response,
    filters as rest_framework_filters,
    permissions as rest_framework_permissions,
    pagination as rest_framework_pagination,
    exceptions as rest_framework_exceptions,
)

from apps.account import (
    models as account_models,
    serializers as account_serializers,
)
from apps.common import constants as common_constants
from apps.group import models as group_models
from apps.post import (
    models as post_models,
    serializers as post_serializers,
    permission as post_permissions,
    filters as post_filters,
)


class PostView(rest_framework_viewsets.ModelViewSet):

    """ Post View: To get,update  Post Details, list """
    serializer_class = post_serializers.PostSerializer
    permission_classes = (rest_framework_permissions.IsAuthenticated,)
    filter_backends = (
        DjangoFilterBackend,
        rest_framework_filters.OrderingFilter,
        rest_framework_filters.SearchFilter,
    )
    filter_class = post_filters.MyPostFilter
    ordering_fields = ('created_at',)
    search_fields = ('title', 'description', 'tag__name',)
    pagination_class = rest_framework_pagination.PageNumberPagination
    http_method_names = ('post', 'patch', 'put', 'get',)

    def get_queryset(self):
        return post_models.Post.objects.prefetch_related('tag_set').filter(
            Q(post_type=common_constants.POST_TYPE.PUBLIC) |
            Q(
                post_type=common_constants.POST_TYPE.PRIVATE, group__in=group_models.Group.objects.filter(
                    usergroupmodel__user_id=self.request.user.id
                )
            )
        ).annotate(
            is_subscribed=~Exists(
                post_models.Post.objects.filter(
                    id=OuterRef('pk'), unsubscribed_user__id=self.request.user.id
                )
            ),
            aggregate_votes=Sum(
                Case(
                    When(
                        reaction__reaction_type=common_constants.REACTION.UPVOTE, then=1,
                    ),
                    When(
                        reaction__reaction_type=common_constants.REACTION.DOWNVOTE, then=-1,
                    ),
                    default=0,
                    output_field=IntegerField()
                )
            ),
            is_bookmarked=Exists(
                post_models.Bookmark.objects.filter(
                    user_id=self.request.user.id,
                    post=OuterRef('pk')
                )
            ),
        )

    def get_permissions(self):
        if self.action == 'partial_update' or self.action == 'update':
            self.permission_classes += (post_permissions.IsOwner, )
        return super().get_permissions()

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return post_serializers.PostReactionSerializer
        return super().get_serializer_class()


class ReactionView(rest_framework_viewsets.ModelViewSet):
    """View to deal with Reaction"""
    serializer_class = post_serializers.ReactionSerializer
    permission_classes = (
        rest_framework_permissions.IsAuthenticated, post_permissions.CanAddReaction, post_permissions.ReactionValidationPermission,
    )
    lookup_field = 'object_id'
    http_method_names = ('post', 'patch', 'put', 'get',)

    def get_queryset(self):
        return post_models.Reaction.objects.filter(
            user=self.request.user, content_type_id=common_constants.CONTENT_TYPE_COMMENT if self.kwargs.get(
                'comment_id'
            ) else common_constants.CONTENT_TYPE_POST
        )


class CommentView(rest_framework_viewsets.ModelViewSet):
    """View to deal with comments"""
    serializer_class = post_serializers.CommentSerializer
    permission_classes = (
        rest_framework_permissions.IsAuthenticated, post_permissions.CanAddReaction,
    )
    filter_backends = [
        django_filters_backend.DjangoFilterBackend,
        rest_framework_filters.OrderingFilter,
    ]
    filter_fields = ('level', 'reply_id',)
    ordering_fields = ('-is_accepted', '-created_at',)
    ordering = ('-is_accepted', '-created_at',)

    def get_queryset(self):
        return post_models.Comment.objects.filter(
            post_id=self.kwargs.get('post_id')
        ).annotate(
            aggregate_votes=Sum(
                Case(
                    When(
                        reaction__reaction_type=common_constants.REACTION.UPVOTE, then=1,
                    ),
                    When(
                        reaction__reaction_type=common_constants.REACTION.DOWNVOTE, then=-1,
                    ),
                    default=0,
                    output_field=IntegerField()
                )
            )
        )

    def get_serializer_class(self):
        if self.action == 'retrieve' or self.action == 'list':
            return post_serializers.CommentReactionSerializer

        return super().get_serializer_class()


class BookmarkView(rest_framework_viewsets.ModelViewSet):
    serializer_class = post_serializers.BookmarkSerializer
    permission_classes = (
        rest_framework_permissions.IsAuthenticated,
    )
    filter_backends = [
        rest_framework_filters.OrderingFilter,
        rest_framework_filters.SearchFilter
    ]
    ordering_fields = ('created_at',)
    search_fields = ('note',)
    http_method_names = ('post', 'patch', 'get',)

    def get_queryset(self):
        return post_models.Bookmark.objects.filter(user=self.request.user)

    def get_permissions(self):
        if self.action == 'create':
            self.permission_classes += (post_permissions.CanAddReaction, )
        return super().get_permissions()

    def get_serializer(self, *args, **kwargs):
        if 'data' in kwargs:
            kwargs['data']['user_id'] = self.request.user.id
        return super().get_serializer(*args, **kwargs)


class TagView(
    rest_framework_viewsets.mixins.ListModelMixin,
    rest_framework_viewsets.GenericViewSet
):

    """ Tag View: To get List of User, Suggestion Tags """
    queryset = post_models.Tag.objects.all()
    serializer_class = post_serializers.TagSerializer
    permission_classes = (rest_framework_permissions.IsAuthenticated,)
    filter_backends = (
        DjangoFilterBackend,
        rest_framework_filters.OrderingFilter,
        rest_framework_filters.SearchFilter,
    )
    filter_class = post_filters.MyTagFilter
    ordering_fields = ('count',)
    ordering = ('-count',)
    search_fields = ('name',)
    pagination_class = rest_framework_pagination.PageNumberPagination
    http_method_names = ('get',)

    def filter_queryset(self, queryset):
        queryset = super().filter_queryset(queryset).annotate(
            count=Count('post'),
            is_followed=Exists(
                post_models.Tag.objects.filter(
                    user=self.request.user,
                    id=OuterRef('pk')
                )
            ),
        )
        return queryset
