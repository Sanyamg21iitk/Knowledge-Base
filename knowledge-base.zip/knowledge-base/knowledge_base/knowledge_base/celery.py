import os
from celery import Celery

from libs.utils import get_settings_module
import class_settings

""" Celery Settings """

os.environ.setdefault("DJANGO_SETTINGS_MODULE", get_settings_module())
os.environ.setdefault('DJANGO_SETTINGS_CLASS', 'Setting')
class_settings.setup()
app = Celery('knowledge_base')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()
