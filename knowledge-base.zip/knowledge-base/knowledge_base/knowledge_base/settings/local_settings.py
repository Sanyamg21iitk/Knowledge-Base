import os
from knowledge_base.settings.base import Setting


class Setting(Setting):

    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    SECRET_KEY = 'YE_MERI_SECRET_KEY_HAI!!!!'
    DEBUG = True
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': 'knowledge_base',
            'USER': 'postgres',
            'PASSWORD': 'shivam@test',
        }
    }

    EMAIL_HOST = 'smtp.gmail.com'
    EMAIL_HOST_USER = 'shivamgarg260@gmail.com'
    EMAIL_HOST_PASSWORD = 'PASSWORD'
    EMAIL_PORT = 587
