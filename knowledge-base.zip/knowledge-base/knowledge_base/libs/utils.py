import os


def get_settings_module():
    if(os.path.exists(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/knowledge_base/settings/local_settings.py')):
        return 'knowledge_base.settings.local_settings'
    else:
        return 'knowledge_base.settings.base'



